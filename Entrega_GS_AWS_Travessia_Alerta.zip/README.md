﻿# Travessia Alerta — Global Solution CitizenTech

FIAP · Global Solution 2026.2  
Plataformas, Serviços Cognitivos e Cloud Computing · Relatório final: 19/11/2026

| Participante | RM |
| --- | --- |
| Luiz Henrique de Paiva Alves Pinto | 572177 |
| Victor Hugo Mielle Bernardes da Silva | 571138 |
| Thomas Ribeiro de Holanda | 570446 |

## Cenário e objetivo

O Travessia Alerta monitora a subida da água em uma passagem junto a um córrego, apoiando pedestres e moradores. O ESP32 integra nível de água, PIR e sinalização local. A nuvem classifica o risco e o sentimento dos relatos e registra os eventos.

A solução se relaciona ao **ODS 11 — Cidades e comunidades sustentáveis**, pela informação preventiva sobre alagamentos. Os limiares são didáticos; a aplicação não constitui um sistema operacional de defesa civil.

## Arquitetura e acesso

```text
ESP32 / simulador → HTTPS Function URL → Lambda
Lambda → autenticação + validação + risco numérico
       → HF Space ZeroGPU → modelo Cardiff
       → TLS → RDS (ocorrencias / base_historica)
       → CloudWatch Logs
```

Lambda: `travessia-alerta-api`, `us-east-1`, Python 3.12, handler `lambda_function.lambda_handler`, 256 MB, timeout 30 s, fora de VPC. RDS com TLS e verificação de certificado/hostname; endpoint sem credenciais: `travessia-alerta-db.cziymy2yitt2.us-east-1.rds.amazonaws.com`.

- [Function URL](https://v6tbxrvk4auxwl2m745s7whosy0quzhc.lambda-url.us-east-1.on.aws)
- [Download do CSV](https://v6tbxrvk4auxwl2m745s7whosy0quzhc.lambda-url.us-east-1.on.aws/dados.csv)
- [Space de sentimento](https://huggingface.co/spaces/ThatsTom/travessia-alerta-ia)

## Contrato da API e proteção

| Rota | Comportamento |
| --- | --- |
| `GET /` | Índice público das rotas. |
| `GET /health` | Verifica somente a aplicação; não consulta banco ou IA. |
| `POST /ocorrencias` | Exige `X-Device-Key` vinculado ao `dispositivo_id`. Retorna 201 após persistência. |
| `GET /ocorrencias?limit=20` | `X-Read-Key` se `READ_API_KEY` estiver definida; senão, chave de dispositivo. Máximo: 100. |
| `GET /dados?limit=100` | Histórico público, com máximo de 1.000 registros por página e `proximo_cursor`. |
| `GET /dados.csv` | Somente histórico, 14 colunas; teto de 30.000 linhas. |

O corpo deve ser um objeto JSON UTF-8 de até 16.384 bytes, após decodificação de base64. `dispositivo_id`, `metrica` e `valor` são obrigatórios: ausência ou `null` produz 400; com os campos presentes, credencial inválida ou ausente produz 401. JSON malformado, duplicatas, números não finitos e tipos inválidos são rejeitados.

Exemplo sintético:

```json
{
  "evento_id": "ta-exemplo-001",
  "dispositivo_id": "esp32-travessia-01",
  "tipo": "esp32",
  "metrica": "nivel_rio_cm",
  "valor": 270,
  "relato": "Relato sintetico: a agua cobriu a passagem."
}
```

`tipo_dispositivo` é alias de `tipo`; ambos devem coincidir quando enviados juntos. `medido_em` exige fuso; `recebido_em` é atribuído em UTC. O mesmo `evento_id` e dados normalizados recuperam o mesmo ID; conteúdo conflitante retorna 409.

Para `nivel_rio_cm`: **<150: `normal`; 150 a <250: `atencao`; ≥250: `critico`**. `alerta=true` indica risco crítico; `ia_ok=true` depende da análise textual. Em falha de IA, a gravação pode retornar 201 com sentimento/confiança nulos e `ia_ok=false`.

As chaves usam `hmac.compare_digest`. `DEVICE_KEYS_JSON` tem prioridade e configuração inválida recusa autenticação. Na sua ausência, utiliza-se `DEVICE_ID` + `DEVICE_KEY`, combinação implantada. Logs: corpo bruto escapado, interpretação, classificação e gravação. Cabeçalhos, segredos e corpos com credenciais detectadas são omitidos. Os relatos demonstrados são sintéticos.

## IA: modelo e adaptação do serviço

O Space Gradio com ZeroGPU gratuito executa `cardiffnlp/twitter-xlm-roberta-base-sentiment`, revisão `f2f1202b1bdeb07342385c3f807f9c07cd8f5cf8`. O Router indicado no material retornou **HTTP 402**, solicitando créditos ou assinatura; a adaptação mantém o mesmo modelo.

A Lambda envia `POST /gradio_api/call/classificar` com `{"data":[texto,chave]}` e consulta o `event_id` por GET/SSE. `event: complete` com as classes `negative`, `neutral` e `positive` e scores válidos confirma a análise. A maior pontuação define o sentimento, sem representar probabilidade de enchente.

O cliente usa `urllib`, prazo total de 20 s, HTTPS restrito a `*.hf.space`, sem redirects e com leitura limitada. HTTP 200 da fila não comprova inferência.

## Base histórica

`base_sp_aguas_tratada.csv` contém **22.062 linhas e 14 colunas**, provenientes do SP Águas/SIBH, posto **1000480**, Córrego Pirajuçara. O período local vai de **06/05/2024 01h a 11/11/2026 06h**; em UTC, de `2024-05-06T04:00:00Z` a `2026-11-11T09:00:00Z`.

SHA-256 do arquivo original:

```text
b70d19b1231c3bf65e566ae84a77a067e82abe5b021cd845211bae622c0d308a
```

A carga preserva lacunas como `NULL`, sem imputar ou recalcular alvos. `/dados` aceita `estacao_id=1000480`, `inicio`, `fim` e `cursor`, com fuso nas datas. O CSV conserva as colunas originais. O limiar histórico de 100 cm tem referência distinta dos 150/250 cm do ESP32.

## Configuração e reprodução

Requisitos: Python 3.12, AWS e Hugging Face. Credenciais são fornecidas separadamente, sem valores nos arquivos públicos.

| Variáveis | Finalidade |
| --- | --- |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | Conexão PostgreSQL. |
| `DB_SSL_CA` | CA da Lambda: `rds-global-bundle.pem`. |
| `DB_CA_FILE` | Caminho da CA para importação e cliente SQL. |
| `DEVICE_KEYS_JSON` ou `DEVICE_ID` + `DEVICE_KEY` | Autenticação vinculada ao dispositivo. |
| `READ_API_KEY` | Chave de consulta de ocorrências. |
| `AI_PROVIDER` | `huggingface` para o Space; padrão do código: `comprehend`. |
| `HF_SPACE_URL`, `HF_SPACE_KEY` | Base HTTPS e segredo de integração, de 32 a 512 caracteres. |
| `HF_TOKEN` | Bearer opcional nos dois pedidos ao Space para quota autenticada. |
| `FUNCTION_URL` | Destino utilizado pelo simulador. |

1. Instalar dependências, validar o CSV e gerar o pacote:

```bash
python -m pip install -r requirements.txt
python importar_base.py --validar
python empacotar.py --output funcao.zip
```

2. Preparar o RDS e a conectividade. Com cliente `psql`, variáveis configuradas e credenciais de implantação, aplicar as tabelas e importar:

```bash
PGPASSWORD="$DB_PASSWORD" psql \
  "host=$DB_HOST port=5432 dbname=$DB_NAME user=$DB_USER sslmode=verify-full sslrootcert=$DB_CA_FILE" \
  -v ON_ERROR_STOP=1 -f tabela_ocorrencias.sql -f base_historica.sql
python importar_base.py
```

3. No console Lambda, enviar `funcao.zip`; definir runtime, handler, timeout, memória, variáveis e role para CloudWatch. Criar Function URL pública e permitir conexão TLS com o RDS. As rotas protegidas exigem autenticação da aplicação.

4. Criar o Space Gradio público ZeroGPU com `apoio/huggingface_space/`. Cadastrar `HF_SPACE_KEY` como Secret e definir a mesma chave e `HF_SPACE_URL` na Lambda. Detalhes no README da pasta.

5. Carregar a chave sem eco no terminal Bash/CloudShell e executar:

```bash
read -r -s -p "Chave do dispositivo: " DEVICE_KEY
export DEVICE_KEY
export FUNCTION_URL="https://v6tbxrvk4auxwl2m745s7whosy0quzhc.lambda-url.us-east-1.on.aws"
python simulador_dispositivo.py --cenario normal --leituras 3
python simulador_dispositivo.py --cenario enchente --leituras 5 --movimento
python -m unittest test_lambda test_seguranca -q
```

## Resultados e evidências

Em **18/11/2026, 21h22 em São Paulo** (19/11, 00h22 UTC), o evento `ta-ia-cc8187fb24bd485fa825a6b390c0761f` retornou **POST 201**, ID **56**, `negative`, confiança **0.8811**, `ia_ok=true`. GET protegido (200), CloudWatch e SELECT no RDS com TLS confirmaram os mesmos dados.

| Arquivo | Comprovação |
| --- | --- |
| `evidencias/ia_huggingface/validacao_http.json` | POST e GET reais do registro 56. |
| `evidencias/ia_huggingface/cloudwatch.json` | Corpo, interpretação, classificação e gravação correlacionados. |
| `evidencias/ia_huggingface/select_rds.json` | Consulta SQL do ID, evento, risco, sentimento e confiança. |
| `evidencias/01_variaveis_ambiente.png`, `evidencias/03_cloudwatch.png`, `evidencias/04_consulta_rds.png`; `evidencias/02_simulador_aws.png` | Configuração, logs e RDS de 18/11; simulador de 15/11/2026. |
| `evidencias/ia_huggingface/teste_router.json` | Resposta 402 que fundamenta a adaptação. |

Os **65 testes offline de Lambda e segurança passaram**, com banco e IA simulados: autenticação, validação, persistência, idempotência, SSE, falhas e segredos. A inferência real está comprovada no registro 56.

Relatório: `gs-citizentech-serverless.pdf`. Roteiro: `ROTEIRO_APRESENTACAO.txt`.

**Vídeo de demonstração, até 5 minutos:** link a preencher após publicação.

## Limites

ZeroGPU tem quota, fila e cold start. O laboratório AWS tem sessões temporárias e restrições institucionais, sem disponibilidade contínua garantida. A base apresenta falhas; os limiares exigem calibração. Uma execução confirma aquele evento.


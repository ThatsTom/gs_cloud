# Base histórica — Travessia Alerta

O arquivo `base_sp_aguas_tratada.csv` reúne **22.062 registros horários e 14 colunas** do SP Águas/SIBH, posto **1000480**, Córrego Pirajuçara, Jardim Maria Sampaio, São Paulo. O período é de **06/05/2024 01h a 11/11/2026 06h**, em `America/Sao_Paulo`. Fonte: [Sistema Integrado de Bacias Hidrográficas](https://cth.daee.sp.gov.br/sibh).

## Tratamento e significado

As séries pluviométrica e fluviométrica foram agregadas por hora. As datas foram convertidas de UTC para o horário de São Paulo. Uma leitura negativa de chuva foi zerada; horas de nível com menos de três leituras de dez minutos foram descartadas. Não houve imputação de lacunas.

O nível relativo utiliza como referência a menor cota média horária da série, **74.547,27 cm**. Duas horas com pico de nível sem chuva nas seis horas anteriores foram excluídas por uma regra heurística. Essa regra constitui uma hipótese de tratamento, sem validação operacional.

O limiar histórico de **100 cm** usa `nivel_max_cm`. É distinto dos limiares didáticos de **150/250 cm** da telemetria do protótipo. Os indicadores do histórico não representam alertas oficiais do posto.

## Colunas

| Coluna | Descrição |
| --- | --- |
| `datahora` | Início da hora local. |
| `chuva_mm_1h` | Chuva acumulada na hora. |
| `chuva_acum_3h`, `chuva_acum_6h`, `chuva_acum_24h`, `chuva_acum_72h` | Acumulados com janela completa; incluem a hora atual. |
| `nivel_cm`, `nivel_max_cm` | Nível médio e máximo da hora, em centímetros relativos. |
| `variacao_nivel_1h`, `variacao_nivel_3h` | Variação do nível médio em uma e três horas. |
| `hora`, `mes` | Hora do dia e mês. |
| `acima_limiar` | Máximo da hora atual maior ou igual a 100 cm. |
| `ultrapassa_3h` | Máximo maior ou igual a 100 cm em alguma das três horas seguintes. |

## Importação e consulta

`base_historica.sql` define a tabela separada das ocorrências. `importar_base.py` valida o arquivo e preserva ausentes como `NULL`, sem recalcular indicadores. A base apresenta **17.515 horas com nível válido** e **17.461 com chuva e nível simultaneamente**.

```bash
python importar_base.py --validar
python importar_base.py
```

Consulta pública: `GET /dados?limit=100`; download completo: `GET /dados.csv`.

SHA-256:

```text
b70d19b1231c3bf65e566ae84a77a067e82abe5b021cd845211bae622c0d308a
```

## Limitações

Os dados representam um único posto, com períodos faltantes e referência relativa calculada sobre a série. O indicador `ultrapassa_3h` depende de observações futuras e não deve ser usado como variável explicativa da mesma janela. A base serve à análise acadêmica; a calibração operacional requer avaliação hidrológica e validação independente.

-- Telemetria do prototipo; historico real usa base_historica.sql.
-- Pode executar novamente sobre a tabela original do professor.
CREATE TABLE IF NOT EXISTS ocorrencias (
    id SERIAL PRIMARY KEY,
    dispositivo_id TEXT NOT NULL,
    tipo_dispositivo TEXT NOT NULL,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    metrica TEXT NOT NULL,
    valor DOUBLE PRECISION NOT NULL,
    relato TEXT,
    sentimento TEXT,
    confianca NUMERIC(5,4),
    nivel_risco TEXT NOT NULL,
    medido_em TIMESTAMPTZ,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS evento_id TEXT;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS ponto_id TEXT;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS origem TEXT;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS distancia_cm DOUBLE PRECISION;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS movimento BOOLEAN;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS status_nivel TEXT;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS status_pir TEXT;
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS recebido_em TIMESTAMPTZ NOT NULL DEFAULT NOW();
ALTER TABLE ocorrencias ADD COLUMN IF NOT EXISTS payload_hash TEXT;

CREATE INDEX IF NOT EXISTS idx_ocorrencias_dispositivo ON ocorrencias (dispositivo_id);
CREATE INDEX IF NOT EXISTS idx_ocorrencias_risco ON ocorrencias (nivel_risco);
CREATE INDEX IF NOT EXISTS idx_ocorrencias_criado ON ocorrencias (criado_em DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ocorrencias_evento_unico
    ON ocorrencias (evento_id) WHERE evento_id IS NOT NULL;

-- Evidencia: preserve evento_id para correlacionar com simulador/CloudWatch.
SELECT id, evento_id, ponto_id, dispositivo_id, origem, metrica, valor,
       nivel_risco, sentimento, confianca, medido_em, recebido_em, criado_em
  FROM ocorrencias ORDER BY id DESC LIMIT 20;

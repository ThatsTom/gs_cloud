-- Historico real SP Aguas/SIBH, separado da telemetria simulada ocorrencias.
-- datahora conserva a hora local do CSV, medido_em registra o mesmo instante UTC.
-- NULL conserva lacunas, sem imputar medicoes ou recalcular alvos.
CREATE TABLE IF NOT EXISTS base_historica (
    estacao_id          TEXT NOT NULL,
    medido_em           TIMESTAMPTZ NOT NULL,
    datahora            TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    chuva_mm_1h         DOUBLE PRECISION,
    chuva_acum_3h       DOUBLE PRECISION,
    chuva_acum_6h       DOUBLE PRECISION,
    chuva_acum_24h      DOUBLE PRECISION,
    chuva_acum_72h      DOUBLE PRECISION,
    nivel_cm           DOUBLE PRECISION,
    nivel_max_cm       DOUBLE PRECISION,
    variacao_nivel_1h   DOUBLE PRECISION,
    variacao_nivel_3h   DOUBLE PRECISION,
    hora                SMALLINT NOT NULL CHECK (hora BETWEEN 0 AND 23),
    mes                 SMALLINT NOT NULL CHECK (mes BETWEEN 1 AND 12),
    acima_limiar        SMALLINT CHECK (acima_limiar IN (0, 1)),
    ultrapassa_3h       SMALLINT CHECK (ultrapassa_3h IN (0, 1)),
    origem              TEXT NOT NULL DEFAULT 'sp_aguas_sibh',
    arquivo_sha256      TEXT NOT NULL CHECK (length(arquivo_sha256) = 64),
    criado_em           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (estacao_id, medido_em)
);

CREATE INDEX IF NOT EXISTS idx_base_historica_medido_em
    ON base_historica (medido_em);

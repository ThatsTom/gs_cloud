﻿---
title: Travessia Alerta Sentimento
emoji: 🌊
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: 6.9.0
python_version: 3.12.12
app_file: app.py
pinned: false
---

# Travessia Alerta — análise de sentimento

Serviço acadêmico Gradio/ZeroGPU gratuito integrado à Lambda do Travessia Alerta. O modelo `cardiffnlp/twitter-xlm-roberta-base-sentiment`, revisão fixa `f2f1202b1bdeb07342385c3f807f9c07cd8f5cf8`, classifica relatos em português como `negative`, `neutral` ou `positive`. O score expressa sentimento, não probabilidade de enchente.

## Execução e dependências

O conjunto validado utiliza Python 3.12.12, Gradio 6.9.0, PyTorch 2.8.0, Transformers 4.57.6 e SentencePiece 0.2.3. O pacote `spaces` é fornecido pela plataforma; `XLMRobertaTokenizer` carrega o tokenizador SentencePiece da revisão fixa.

`spaces` é importado antes de PyTorch. A declaração global `.to("cuda")` é emulada no processo web; a GPU real e a materialização dos pesos pertencem ao worker `@spaces.GPU(duration=10)`. Os resultados retornam como objetos Python. O carregamento utiliza `weights_only=True` e `trust_remote_code=False`.

## API e proteção

O endpoint `classificar` recebe `texto` e `chave`, nessa ordem. O texto tem até 2.000 caracteres e a tokenização é limitada a 512 tokens.

```text
POST /gradio_api/call/classificar
{"data":["Relato sintético em português","<segredo de integração>"]}

Resposta: {"event_id":"<identificador>"}
GET /gradio_api/call/classificar/<identificador>
```

Resultado SSE, com scores ilustrativos:

```text
event: complete
data: [[{"label":"negative","score":0.8},{"label":"neutral","score":0.15},{"label":"positive","score":0.05}]]
```

A saída contém as três classes e scores finitos entre 0 e 1, com soma aproximada de 1. A maior pontuação define o sentimento. HTTP 200 da fila não representa inferência concluída.

O Secret `HF_SPACE_KEY` contém a chave de ao menos 32 caracteres, compartilhada com a Lambda e comparada com `hmac.compare_digest`. Configuração ausente ou inválida recusa a inferência com erro genérico. A chave permanece no JSON, sem exposição em URL ou logs. `HF_TOKEN` é Bearer opcional nos dois pedidos da Lambda para quota autenticada; não substitui a chave do aplicativo.

## Implantação e limites

A estrutura do Space contém três arquivos: `app.py`, `requirements.txt` e `README.md`. A implantação utiliza SDK Gradio, visibilidade pública, hardware ZeroGPU e `HF_SPACE_KEY` em Settings → Variables and secrets.

A fila admite oito jobs e uma execução por vez. Quota, fila e cold start afetam a disponibilidade; o limite de 10 segundos do worker não inclui toda a espera. A chave é validada dentro do handler decorado. A demonstração utiliza relatos sintéticos; o aplicativo não grava texto ou chave em banco, arquivos ou logs próprios.

Validação de 18/11/2026: registro 56, `negative`, confiança `0.8811` e `ia_ok=true`. Evidência: `evidencias/ia_huggingface/validacao_http.json` na entrega AWS.


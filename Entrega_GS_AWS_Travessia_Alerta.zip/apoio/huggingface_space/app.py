"""Classificador acadêmico de sentimento: Gradio + Hugging Face ZeroGPU.

O serviço é público, mas a inferência exige a chave privada HF_SPACE_KEY.
Não contém acesso ao banco, credenciais AWS ou registro do texto recebido.
"""

import os

# Evita paralelismo do tokenizador herdado por processos de inferência.
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("GRADIO_ANALYTICS_ENABLED", "False")

# O runtime ZeroGPU instala e configura spaces; deve preceder o uso de CUDA.
import spaces
import gradio as gr
import hmac
import math
import torch
from transformers import AutoModelForSequenceClassification, XLMRobertaTokenizer


MODEL_ID = "cardiffnlp/twitter-xlm-roberta-base-sentiment"
# SHA obtido dos metadados públicos oficiais do repositório em 18/11/2026.
MODEL_REVISION = "f2f1202b1bdeb07342385c3f807f9c07cd8f5cf8"
MAX_TEXT_CHARS = 2000
MAX_TOKENS = 512
LABELS = {"negative", "neutral", "positive"}


def _chave_valida(recebida: str) -> bool:
    """Sem configuração válida, toda inferência é negada; não há chave padrão."""
    esperada = os.environ.get("HF_SPACE_KEY")
    if not isinstance(esperada, str) or len(esperada) < 32 or not esperada.strip():
        return False
    if not isinstance(recebida, str) or not recebida or len(recebida) > 512:
        return False
    try:
        return hmac.compare_digest(recebida.encode("utf-8"), esperada.encode("utf-8"))
    except UnicodeError:
        return False


def _validar_texto(texto: str) -> str:
    if not isinstance(texto, str) or not texto.strip() or len(texto) > MAX_TEXT_CHARS:
        raise gr.Error("Informe um texto de 1 a 2000 caracteres, sem dados pessoais.")
    return texto.strip()


# O modelo é público: não é necessário expor um token HF para baixar os pesos.
# Esta revisão possui SentencePiece, mas não tokenizer.json. A classe lenta
# explícita lê sentencepiece.bpe.model diretamente; não passa pela conversão
# automática de Transformers 5 nem por TiktokenConverter.
_TOKENIZADOR = XLMRobertaTokenizer.from_pretrained(
    MODEL_ID,
    revision=MODEL_REVISION,
    trust_remote_code=False,
    token=False,
)
# O padrão oficial ZeroGPU declara o modelo em CUDA no escopo global para
# preparar os pesos no startup e reutilizá-los eficientemente nos workers.
# Como spaces foi importado primeiro, .to('cuda') é emulado no processo web;
# a GPU real e a materialização dos pesos pertencem ao worker do decorator.
# Não consultar torch.cuda.is_available() nesta inicialização.
_MODELO = AutoModelForSequenceClassification.from_pretrained(
    MODEL_ID,
    revision=MODEL_REVISION,
    trust_remote_code=False,
    token=False,
    # Esta revisão oficial oferece pytorch_model.bin, não model.safetensors.
    # O carregamento usa apenas pesos, pelo loader atualizado do PyTorch.
    use_safetensors=False,
    weights_only=True,
).eval().to("cuda")


@spaces.GPU(duration=10)
def classificar(texto: str, chave: str) -> list[dict]:
    """Devolve os três rótulos e scores, exigindo a chave de integração privada.

    Args:
        texto: Relato sintético em português, até 2000 caracteres.
        chave: Chave de integração HF_SPACE_KEY, diferente do token da conta HF.
    """
    if not _chave_valida(chave):
        # Mensagem fixa: nunca reflete a chave recebida ou esperada.
        raise gr.Error("Credencial de integração ausente ou inválida.")
    texto = _validar_texto(texto)
    try:
        if not torch.cuda.is_available():
            raise RuntimeError("GPU indisponível")
        # Estas operações ocorrem apenas no worker atribuído pelo ZeroGPU.
        tokens = _TOKENIZADOR(
            texto, return_tensors="pt", truncation=True, max_length=MAX_TOKENS,
        )
        tokens = {nome: tensor.to("cuda") for nome, tensor in tokens.items()}
        with torch.no_grad():
            logits = _MODELO(**tokens).logits[0].float()
            scores = torch.softmax(logits, dim=-1).detach().cpu().tolist()
        resultado = [
            {"label": str(_MODELO.config.id2label[indice]).lower(), "score": float(score)}
            for indice, score in enumerate(scores)
        ]
        if (
            len(resultado) != 3
            or {item["label"] for item in resultado} != LABELS
            or any(not math.isfinite(item["score"]) or not 0 <= item["score"] <= 1 for item in resultado)
            or not math.isclose(sum(item["score"] for item in resultado), 1.0, abs_tol=1e-5)
        ):
            raise RuntimeError("Saída do modelo inválida")
        # Somente objetos Python saem do worker; não retornar tensores CUDA.
        return resultado
    except Exception:
        # Não expõe exceções internas, texto, tokens ou segredos ao cliente.
        raise gr.Error("Análise temporariamente indisponível; tente novamente mais tarde.") from None


with gr.Blocks(title="Travessia Alerta — sentimento", analytics_enabled=False) as demo:
    gr.Markdown(
        "# Travessia Alerta — análise acadêmica de sentimento\n"
        "Classifica relatos sintéticos em português como negativo, neutro ou positivo. "
        "O resultado não indica risco de enchente nem substitui o limiar do sensor.\n\n"
        "Este Space tem código e página públicos. A inferência exige uma **chave "
        "privada de integração**, entregue separadamente ao operador. "
        "Não insira o token da sua conta Hugging Face e não envie dados pessoais."
    )
    texto_input = gr.Textbox(label="Relato sintético", lines=3, max_length=MAX_TEXT_CHARS)
    chave_input = gr.Textbox(label="Chave de integração (não é o token da conta HF)", type="password")
    executar = gr.Button("Classificar")
    saida = gr.JSON(label="Rótulos e scores")
    executar.click(
        fn=classificar,
        inputs=[texto_input, chave_input],
        outputs=saida,
        api_name="classificar",
        concurrency_limit=1,
    )

demo.queue(max_size=8, default_concurrency_limit=1)

if __name__ == "__main__":
    demo.launch(show_error=False)

"""Autenticacao da API Travessia Alerta, sem segredos no codigo.

Configuracao da Lambda:
    DEVICE_KEYS_JSON: objeto JSON {dispositivo_id: chave}. Uma chave deve ser
        aleatoria (por exemplo, secrets.token_urlsafe(32)) e exclusiva por sensor.
    DEVICE_ID + DEVICE_KEY: alternativa para um unico sensor, usada somente
        quando DEVICE_KEYS_JSON nao estiver definida. JSON invalido nunca
        habilita esse fallback.
    READ_API_KEY: opcional. Se definida, GET protegido exige X-Read-Key.
        Sem ela, GET aceita X-Device-Key de qualquer sensor cadastrado.
    MAX_BODY_BYTES: limite UTF-8 do corpo, padrao 16384 bytes.

POST exige X-Device-Key correspondente ao dispositivo_id do proprio corpo.
Os nomes dos cabecalhos sao insensiveis a maiusculas. Configuracao ausente,
invalida ou cabecalhos ambiguos negam acesso. Nao registre chaves em logs.
As funcoes retornam bool; o handler deve responder 401 quando receber False.
"""

import hmac
import json
import os
from collections.abc import Mapping


LIMITE_CORPO_PADRAO = 16_384


def _texto_valido(valor):
    return isinstance(valor, str) and bool(valor.strip())


def _objeto_sem_duplicatas(pares):
    objeto = {}
    for chave, valor in pares:
        if chave in objeto:
            raise ValueError("identificador duplicado na configuracao")
        objeto[chave] = valor
    return objeto


def _chaves_dispositivos():
    configuracao = os.environ.get("DEVICE_KEYS_JSON")
    if configuracao is not None:
        try:
            chaves = json.loads(configuracao, object_pairs_hook=_objeto_sem_duplicatas)
        except (TypeError, ValueError):
            return {}
        if not isinstance(chaves, dict) or not chaves:
            return {}
        if not all(_texto_valido(k) and _texto_valido(v) for k, v in chaves.items()):
            return {}
        return chaves

    dispositivo = os.environ.get("DEVICE_ID")
    chave = os.environ.get("DEVICE_KEY")
    if _texto_valido(dispositivo) and _texto_valido(chave):
        return {dispositivo: chave}
    return {}


def _cabecalho(headers, nome):
    if not isinstance(headers, Mapping):
        return None
    encontrados = [
        valor for chave, valor in headers.items()
        if isinstance(chave, str) and chave.lower() == nome.lower()
    ]
    if len(encontrados) != 1 or not _texto_valido(encontrados[0]):
        return None
    return encontrados[0]


def _iguais(recebida, esperada):
    if not _texto_valido(recebida) or not _texto_valido(esperada):
        return False
    try:
        return hmac.compare_digest(recebida.encode("utf-8"), esperada.encode("utf-8"))
    except UnicodeError:
        return False


def autenticar_dispositivo(headers, dispositivo_id):
    """Confere X-Device-Key exclusivamente para a identidade informada no POST."""
    if not _texto_valido(dispositivo_id):
        return False
    esperada = _chaves_dispositivos().get(dispositivo_id)
    return _iguais(_cabecalho(headers, "X-Device-Key"), esperada)


def autenticar_leitura(headers):
    """Confere X-Read-Key configurada ou, sem ela, uma X-Device-Key cadastrada."""
    chave_leitura = os.environ.get("READ_API_KEY")
    if chave_leitura is not None:
        return _iguais(_cabecalho(headers, "X-Read-Key"), chave_leitura)

    recebida = _cabecalho(headers, "X-Device-Key")
    # Avalia todas as chaves, sem encerrar na primeira coincidencia.
    permitida = False
    for esperada in _chaves_dispositivos().values():
        permitida |= _iguais(recebida, esperada)
    return bool(permitida)


def limite_corpo_bytes():
    """Limite positivo configurado; configuracao invalida usa o padrao seguro."""
    try:
        limite = int(os.environ.get("MAX_BODY_BYTES", str(LIMITE_CORPO_PADRAO)))
    except (TypeError, ValueError):
        return LIMITE_CORPO_PADRAO
    return limite if limite > 0 else LIMITE_CORPO_PADRAO


def corpo_no_limite(corpo):
    """Valida tamanho em bytes do corpo ja decodificado de base64 pelo handler."""
    if corpo is None:
        return True
    if isinstance(corpo, str):
        try:
            corpo = corpo.encode("utf-8")
        except UnicodeError:
            return False
    if not isinstance(corpo, bytes):
        return False
    return len(corpo) <= limite_corpo_bytes()

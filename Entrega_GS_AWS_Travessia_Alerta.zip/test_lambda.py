"""Testes de contrato locais. Banco/servicos AWS simulados, sem chamadas de rede."""

import base64
import csv
import io
import json
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError
from urllib.parse import urlencode

import lambda_function as fn


def evento(metodo="POST", caminho="/ocorrencias", payload=None, autorizado=True, query=None):
    if payload is None:
        payload = {"dispositivo_id": "esp32-travessia-01", "metrica": "nivel_rio_cm", "valor": 270}
    return {
        "rawPath": caminho,
        "requestContext": {"http": {"method": metodo}},
        "headers": {"X-Device-Key": "chave-ficticia-local"} if autorizado else {},
        "body": json.dumps(payload),
        "rawQueryString": urlencode(query or {}),
    }


def linha_historica(hora=0):
    utc = datetime(2024, 5, 6, 4, tzinfo=timezone.utc) + timedelta(hours=hora)
    return (
        "1000480", utc, utc.replace(tzinfo=None) - timedelta(hours=3),
        0.0, None, None, None, None, 18.5, 20.93, None, None,
        (1 + hora) % 24, 5, 0, 0, "sp_aguas_sibh",
    )


class RespostaSpaceSimulada(io.BytesIO):
    """Transporte Gradio exclusivamente local: nunca abre conexoes."""
    def __init__(self, corpo):
        super().__init__(corpo)
        self.socket_simulado = MagicMock()
        self.fp = SimpleNamespace(raw=SimpleNamespace(_sock=self.socket_simulado))


class LambdaTests(unittest.TestCase):
    def setUp(self):
        ambiente = patch.dict(os.environ, {
            "DEVICE_KEYS_JSON": json.dumps({"esp32-travessia-01": "chave-ficticia-local"}),
            "AI_PROVIDER": "comprehend",
        }, clear=True)
        ambiente.start()
        self.addCleanup(ambiente.stop)

    def test_health_sem_banco_ou_segredos(self):
        with patch.object(fn, "conectar") as banco:
            r = fn.lambda_handler(evento("GET", "/health", autorizado=False), None)
        self.assertEqual(r["statusCode"], 200)
        self.assertEqual(json.loads(r["body"])["verificacao"], "aplicacao")
        self.assertNotIn("chave", r["body"])
        self.assertNotIn("DB_", r["body"])
        banco.assert_not_called()

    def test_raiz_tem_links_para_dados(self):
        r = fn.lambda_handler(evento("GET", "/", autorizado=False), None)
        self.assertEqual(r["statusCode"], 200)
        self.assertEqual(json.loads(r["body"])["download_csv"], "/dados.csv")

    def test_sem_credencial_loga_corpo_ficticio_sem_chamar_ia_ou_banco(self):
        ev = evento(autorizado=False)
        payload = json.loads(ev["body"])
        payload["relato"] = "Relato ficticio: passagem sem alagamento"
        ev["body"] = json.dumps(payload)
        with patch.object(fn, "analisar_relato") as ia, patch.object(fn, "gravar_ocorrencia") as db:
            with self.assertLogs(fn.logger, level="INFO") as logs:
                r = fn.lambda_handler(ev, None)
        self.assertEqual(r["statusCode"], 401)
        self.assertIn(payload["relato"], " ".join(logs.output))
        self.assertIn("WARNING", " ".join(logs.output))
        ia.assert_not_called()
        db.assert_not_called()

    def test_ausencia_dispositivo_retorna_400_antes_de_autenticar(self):
        self._verificar_campo_obrigatorio_ausente("dispositivo_id")

    def test_ausencia_metrica_retorna_400_antes_de_autenticar(self):
        self._verificar_campo_obrigatorio_ausente("metrica")

    def test_ausencia_valor_retorna_400_antes_de_autenticar(self):
        self._verificar_campo_obrigatorio_ausente("valor")

    def _verificar_campo_obrigatorio_ausente(self, campo):
        payload = json.loads(evento()["body"])
        del payload[campo]
        with patch.object(fn, "autenticar_dispositivo") as auth, patch.object(fn, "gravar_ocorrencia") as db:
            for autorizado in (True, False):
                with self.subTest(autorizado=autorizado):
                    retorno = fn.lambda_handler(evento(payload=payload, autorizado=autorizado), None)
                    self.assertEqual(retorno["statusCode"], 400)
                    self.assertIn(campo, json.loads(retorno["body"])["erro"])
        auth.assert_not_called()
        db.assert_not_called()

    def test_campos_presentes_com_credencial_invalida_retornam_401(self):
        ev = evento()
        ev["headers"]["X-Device-Key"] = "credencial-incorreta-ficticia"
        with patch.object(fn, "analisar_relato") as ia, patch.object(fn, "gravar_ocorrencia") as db:
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 401)
        ia.assert_not_called()
        db.assert_not_called()

    def test_tipo_contrato_alias_e_ambos_iguais(self):
        padrao = json.loads(evento()["body"])
        for campos in ({"tipo": "esp32"}, {"tipo_dispositivo": "esp32"},
                       {"tipo": "esp32", "tipo_dispositivo": "esp32"}, {}):
            with self.subTest(campos=campos):
                with patch.object(fn, "gravar_ocorrencia", return_value=(9, datetime.now(timezone.utc))) as db:
                    retorno = fn.lambda_handler(evento(payload={**padrao, **campos}), None)
                self.assertEqual(retorno["statusCode"], 201)
                esperado = "esp32" if campos else "desconhecido"
                self.assertEqual(db.call_args.args[0]["tipo_dispositivo"], esperado)
                self.assertEqual(json.loads(retorno["body"])["tipo_dispositivo"], esperado)

    def test_tipos_divergentes_ou_invalidos_retornam_400(self):
        padrao = json.loads(evento()["body"])
        with patch.object(fn, "gravar_ocorrencia") as db:
            for campos in ({"tipo": "esp32", "tipo_dispositivo": "simulador"},
                           {"tipo": None}, {"tipo": []}, {"tipo": ""}):
                with self.subTest(campos=campos):
                    self.assertEqual(fn.lambda_handler(evento(payload={**padrao, **campos}), None)["statusCode"], 400)
        db.assert_not_called()

    def test_alias_tipo_preserva_hash_idempotente(self):
        padrao = json.loads(evento()["body"])
        with patch.object(fn, "gravar_ocorrencia", return_value=(9, datetime.now(timezone.utc))) as db:
            fn.lambda_handler(evento(payload={**padrao, "tipo": "esp32"}), None)
            hash_tipo = db.call_args.args[0]["payload_hash"]
            fn.lambda_handler(evento(payload={**padrao, "tipo_dispositivo": "esp32"}), None)
            self.assertEqual(hash_tipo, db.call_args.args[0]["payload_hash"])

    def test_identidade_diferente_nega(self):
        ev = evento(payload={"dispositivo_id": "esp32-outro", "metrica": "nivel_rio_cm", "valor": 1})
        self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 401)

    def test_payload_minimo_201_preserva_hora_ausente(self):
        with patch.object(fn, "gravar_ocorrencia", return_value=(41, datetime.now(timezone.utc))) as db:
            r = fn.lambda_handler(evento(), None)
        self.assertEqual(r["statusCode"], 201)
        retorno = json.loads(r["body"])
        self.assertEqual((retorno["id"], retorno["nivel_risco"], retorno["alerta"]), (41, "critico", True))
        dados = db.call_args.args[0]
        self.assertIsNone(dados["medido_em"])
        self.assertIsNotNone(dados["recebido_em"].tzinfo)
        self.assertEqual(len(dados["payload_hash"]), 64)

    def test_evento_estendido_preserva_contrato_e_recalcula_risco(self):
        payload = {
            "evento_id": "ta-wokwi-0003", "ponto_id": "travessia-01",
            "dispositivo_id": "esp32-travessia-01", "tipo_dispositivo": "esp32",
            "origem": "wokwi", "medido_em": "2026-11-10T19:00:00-03:00",
            "metrica": "nivel_rio_cm", "valor": 270.0, "distancia_cm": 30.0,
            "movimento": True, "status_nivel": "normal", "status_pir": "movimento",
        }
        with patch.object(fn, "gravar_ocorrencia", return_value=(42, datetime.now(timezone.utc))) as db:
            r = fn.lambda_handler(evento(payload=payload), None)
        retorno = json.loads(r["body"])
        self.assertEqual((r["statusCode"], retorno["evento_id"], retorno["ponto_id"]), (201, "ta-wokwi-0003", "travessia-01"))
        self.assertEqual(retorno["nivel_risco"], "critico")
        self.assertEqual(db.call_args.args[0]["medido_em"], datetime(2026, 11, 10, 22, tzinfo=timezone.utc))

    def test_limites_inclusivos_e_invertidos(self):
        casos = [(149.99, "normal"), (150, "atencao"), (249.99, "atencao"), (250, "critico")]
        for valor, esperado in casos:
            self.assertEqual(fn.classificar_risco("nivel_rio_cm", valor), esperado)
        self.assertEqual(fn.classificar_risco("umidade_solo_pct", 10), "critico")
        self.assertEqual(fn.classificar_risco("umidade_solo_pct", 20), "atencao")
        self.assertEqual(fn.classificar_risco("umidade_solo_pct", 21), "normal")

    def test_payloads_invalidos_retornam_400_sem_persistir(self):
        padrao = json.loads(evento()["body"])
        casos = [
            {"dispositivo_id": "esp32-travessia-01"},
            {**padrao, "valor": True}, {**padrao, "valor": "270"},
            {**padrao, "valor": float("inf")}, {**padrao, "valor": float("nan")},
            {**padrao, "valor": 10**400},
            {**padrao, "metrica": []}, {**padrao, "metrica": "nao_suportada"},
            {**padrao, "medido_em": "2026-11-10T22:00:00"},
            {**padrao, "medido_em": "0001-01-01T00:00:00+03:00"},
            {**padrao, "latitude": 91}, {**padrao, "longitude": False},
            {**padrao, "movimento": "true"}, {**padrao, "status_pir": []},
            {**padrao, "movimento": True, "status_pir": "sem_movimento"},
            {**padrao, "relato": "\ud800"}, {**padrao, "evento_id": "x\nlog falso"},
            {**padrao, "relato": "a\x00b"},
            {**padrao, "relato": "a" * 2001},
        ]
        with patch.object(fn, "gravar_ocorrencia") as db:
            for payload in casos:
                with self.subTest(payload=repr(payload)[:120]):
                    self.assertEqual(fn.lambda_handler(evento(payload=payload), None)["statusCode"], 400)
        db.assert_not_called()

    def test_formato_corpo_json_e_base64(self):
        ev = evento()
        for invalido in ("[]", "null", "1", '"texto"', "{", " ", '{"a":1,"a":2}', "1" * 5000):
            with self.subTest(invalido=invalido[:30]):
                ev["body"] = invalido
                self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)
        ev = evento()
        ev["isBase64Encoded"] = True
        ev["body"] = base64.b64encode(ev["body"].encode()).decode()
        with patch.object(fn, "gravar_ocorrencia", return_value=(1, datetime.now(timezone.utc))):
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 201)
        for invalido in ("%%%%", "á", base64.b64encode(b"\xff").decode()):
            ev["body"] = invalido
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)

    def test_corpo_grande_rejeitado_antes_da_ia(self):
        ev = evento()
        ev["body"] = " " * 16385
        with patch.object(fn, "analisar_relato") as ia:
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)
        ia.assert_not_called()
        ev["isBase64Encoded"] = True
        ev["body"] = base64.b64encode(b"x" * 16385).decode()
        self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)

    def test_falha_ia_nao_interrompe_ingestao(self):
        payload = {**json.loads(evento()["body"]), "relato": "A agua subiu na passagem"}
        with patch.object(fn, "_analisar_comprehend", side_effect=TimeoutError("sem rede")):
            with patch.object(fn, "gravar_ocorrencia", return_value=(8, datetime.now(timezone.utc))) as db:
                r = fn.lambda_handler(evento(payload=payload), None)
        self.assertEqual(r["statusCode"], 201)
        self.assertEqual(json.loads(r["body"])["nivel_risco"], "critico")
        self.assertIs(json.loads(r["body"])["ia_ok"], False)
        self.assertIsNone(db.call_args.args[0]["sentimento"])

    def test_space_local_contrato_completo_ia_ok_sem_alerta_numerico(self):
        chave = "chave-Space-ficticia-exclusiva-teste-123"
        os.environ.update(AI_PROVIDER="huggingface", HF_SPACE_URL="https://grupo-travessia.hf.space/", HF_SPACE_KEY=chave)
        payload = {**json.loads(evento()["body"]), "valor": 90, "relato": "Relato sintetico da passagem", "evento_id": "space-local-01"}
        fila = RespostaSpaceSimulada(b'{"event_id":"fila_abc-123"}')
        sse = RespostaSpaceSimulada(
            b': ping\n\nevent: heartbeat\ndata: null\n\nevent: complete\n'
            b'data: [[{"label":"negative","score":0.90002},{"label":"neutral","score":0.09997},{"label":"positive","score":0.00001}]]\n\n')
        cliente = MagicMock()
        cliente.open.side_effect = [fila, sse]
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente), patch.object(fn.urllib.request, "urlopen") as router:
            with patch.object(fn, "gravar_ocorrencia", return_value=(70, datetime.now(timezone.utc))) as banco:
                with self.assertLogs(fn.logger, level="INFO") as logs:
                    retorno = fn.lambda_handler(evento(payload=payload), None)
        corpo = json.loads(retorno["body"])
        self.assertEqual(retorno["statusCode"], 201)
        self.assertEqual((corpo["sentimento"], corpo["confianca"], corpo["nivel_risco"]), ("negative", 0.9, "normal"))
        self.assertIs(corpo["ia_ok"], True)
        self.assertIs(corpo["alerta"], False)
        post, get = cliente.open.call_args_list
        self.assertEqual(post.args[0].full_url, "https://grupo-travessia.hf.space/gradio_api/call/classificar")
        self.assertEqual(json.loads(post.args[0].data), {"data": [payload["relato"], chave]})
        self.assertEqual(get.args[0].full_url, "https://grupo-travessia.hf.space/gradio_api/call/classificar/fila_abc-123")
        self.assertEqual(get.args[0].get_method(), "GET")
        self.assertIsNone(post.args[0].get_header("Authorization"))
        self.assertIsNone(get.args[0].get_header("Authorization"))
        self.assertTrue(all(0 < chamada.kwargs["timeout"] <= 20 for chamada in cliente.open.call_args_list))
        self.assertNotIn("ia_ok", banco.call_args.args[0])
        self.assertNotIn("ia_ok", fn.COLUNAS_OCORRENCIA)
        self.assertTrue(any("ia_ok=true" in registro for registro in logs.output))
        self.assertNotIn(chave, " ".join(logs.output))
        router.assert_not_called()

    def test_space_token_opcional_quota_post_e_get_sem_vazar_logs(self):
        chave = "chave-Space-ficticia-exclusiva-teste-123"
        token = "hf_token_ficticio_somente_teste_local"
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo-travessia.hf.space", HF_SPACE_KEY=chave, HF_TOKEN=token)
        payload = {**json.loads(evento()["body"]), "relato": "Relato sintetico de teste"}
        cliente = MagicMock()
        cliente.open.side_effect = [
            RespostaSpaceSimulada(b'{"event_id":"fila-autenticada"}'),
            RespostaSpaceSimulada(b'event: complete\ndata: [[{"label":"negative","score":0.9},{"label":"neutral","score":0.08},{"label":"positive","score":0.02}]]\n\n'),
        ]
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
            with patch.object(fn, "gravar_ocorrencia", return_value=(74, datetime.now(timezone.utc))):
                with self.assertLogs(fn.logger, level="INFO") as logs:
                    retorno = fn.lambda_handler(evento(payload=payload), None)
        self.assertIs(json.loads(retorno["body"])["ia_ok"], True)
        for chamada in cliente.open.call_args_list:
            req = chamada.args[0]
            self.assertEqual(req.get_header("Authorization"), "Bearer " + token)
            self.assertNotIn(chave, str(req.headers))
            self.assertNotIn(chave, req.full_url)
            self.assertNotIn(token, req.full_url)
        self.assertNotIn(token, cliente.open.call_args_list[0].args[0].data.decode())
        self.assertNotIn(token, " ".join(logs.output))
        self.assertNotIn(chave, " ".join(logs.output))

    def test_space_falha_critico_grava_201_e_ia_false_sem_segredo(self):
        chave = "chave-Space-ficticia-exclusiva-teste-456"
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo-travessia.hf.space", HF_SPACE_KEY=chave)
        payload = {**json.loads(evento()["body"]), "relato": "Relato sintetico"}
        cliente = MagicMock()
        cliente.open.side_effect = TimeoutError(chave)
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
            with patch.object(fn, "gravar_ocorrencia", return_value=(71, datetime.now(timezone.utc))):
                with self.assertLogs(fn.logger, level="INFO") as logs:
                    retorno = fn.lambda_handler(evento(payload=payload), None)
        corpo = json.loads(retorno["body"])
        self.assertEqual(retorno["statusCode"], 201)
        self.assertIs(corpo["alerta"], True)
        self.assertIs(corpo["ia_ok"], False)
        self.assertIsNone(corpo["sentimento"])
        self.assertIn("ia_ok=false", " ".join(logs.output))
        self.assertNotIn(chave, " ".join(logs.output))

    def test_sem_relato_ia_false_sem_chamada_space(self):
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo-travessia.hf.space", HF_SPACE_KEY="chave-ficticia-" * 3)
        with patch.object(fn.urllib.request, "build_opener") as cliente:
            with patch.object(fn, "gravar_ocorrencia", return_value=(72, datetime.now(timezone.utc))):
                retorno = fn.lambda_handler(evento(), None)
        self.assertIs(json.loads(retorno["body"])["ia_ok"], False)
        cliente.assert_not_called()

    def test_space_url_chave_e_event_id_invalidos_nao_seguem_url_externa(self):
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_KEY="chave-ficticia-" * 3, HF_TOKEN="token-router-ficticio")
        with patch.object(fn.urllib.request, "build_opener") as cliente, patch.object(fn.urllib.request, "urlopen") as router:
            for url in ("", "http://grupo.hf.space", "https://hf.space", "https://grupo.hf.space.evil.example", "https://grupo.hf.space@evil.example", "https://usuario@grupo.hf.space", "https://grupo.hf.space:443", "https://grupo.hf.space/caminho", "https://grupo.hf.space?x=1", "https://grupo.hf.space#x", "https://grupo..hf.space", "https://grupo.hf.space\\evil", " https://grupo.hf.space", "https://gru\npo.hf.space"):
                with self.subTest(url=url):
                    os.environ["HF_SPACE_URL"] = url
                    self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
            cliente.assert_not_called()
            router.assert_not_called()
        os.environ["HF_SPACE_URL"] = "https://grupo.hf.space"
        for invalida in ("", "curta"):
            os.environ["HF_SPACE_KEY"] = invalida
            with patch.object(fn.urllib.request, "build_opener") as cliente:
                self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
                cliente.assert_not_called()
        os.environ["HF_SPACE_KEY"] = "chave-ficticia-" * 3
        for evento_id in (None, "../outro", "https://evil.example", "x?token=1", "x" * 129):
            cliente = MagicMock()
            cliente.open.return_value = RespostaSpaceSimulada(json.dumps({"event_id": evento_id}).encode())
            with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
                self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
            self.assertEqual(cliente.open.call_count, 1)

    def test_space_nao_segue_redirecionamento(self):
        req = fn.urllib.request.Request("https://grupo.hf.space")
        self.assertIsNone(fn._SemRedirecionamento().redirect_request(req, None, 302, "", {}, "https://outro.example"))
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo.hf.space", HF_SPACE_KEY="chave-ficticia-" * 3)
        cliente = MagicMock()
        cliente.open.side_effect = HTTPError(req.full_url, 302, "redirect", {}, None)
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente) as construir:
            self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
        self.assertIsInstance(construir.call_args.args[0], fn._SemRedirecionamento)
        self.assertEqual(cliente.open.call_count, 1)

    def test_space_sse_malformado_e_respostas_limitadas(self):
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo.hf.space", HF_SPACE_KEY="chave-ficticia-" * 3)
        invalidas = (b'event: complete\ndata: {"erro":"indisponivel"}\n\n',
                     b'event: complete\ndata: [[{"label":"erro","score":1.0}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":1.0}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":0.8},{"label":"neutral","score":0.8},{"label":"positive","score":0.8}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":0.8},{"label":"negative","score":0.1},{"label":"positive","score":0.1}]]\n\n',
                     b'event: complete\ndata: [[{"label":" ","score":0.9}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":true}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":NaN}]]\n\n',
                     b'event: complete\ndata: [[{"label":"negative","score":1.1}]]\n\n',
                     b'event: error\ndata: "indisponivel"\n\n',
                     b'event: heartbeat\ndata: null\n\n', b'evento incorreto\n\n',
                     b'event: complete\ndata: [', b'event: complete\ndata: \xff\n\n',
                     b'data: ' + b'x' * 65_537 + b'\n\n',
                     (b': heartbeat\n\n' * 22_000))
        for corpo in invalidas:
            with self.subTest(inicio=corpo[:50]):
                cliente = MagicMock()
                cliente.open.side_effect = [RespostaSpaceSimulada(b'{"event_id":"fila"}'), RespostaSpaceSimulada(corpo)]
                with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
                    self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
        cliente = MagicMock()
        cliente.open.return_value = RespostaSpaceSimulada(b"x" * 4097)
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
            self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
        self.assertEqual(cliente.open.call_count, 1)

    def test_space_deadline_total_nao_renovado_por_heartbeats(self):
        class Relogio:
            agora = 100.0
            def monotonic(self):
                return self.agora

        relogio = Relogio()

        class Heartbeats(RespostaSpaceSimulada):
            def read1(self, tamanho):
                relogio.agora += 6
                return b"event: heartbeat\ndata: null\n\n"

        sse = Heartbeats(b"")
        cliente = MagicMock()
        cliente.open.side_effect = [RespostaSpaceSimulada(b'{"event_id":"fila"}'), sse]
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo.hf.space", HF_SPACE_KEY="chave-ficticia-" * 3)
        with patch.object(fn.time, "monotonic", side_effect=relogio.monotonic):
            with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
                self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
        tempos = [chamada.args[0] for chamada in sse.socket_simulado.settimeout.call_args_list]
        self.assertEqual(tempos, [20, 14, 8, 2])
        self.assertEqual(cliente.open.call_count, 2)
        self.assertTrue(sse.closed)

    def test_space_chave_copiada_no_relato_omitida_dos_logs(self):
        chave = "chave-Space-ficticia-exclusiva-teste-789"
        os.environ.update(AI_PROVIDER="hf", HF_SPACE_URL="https://grupo.hf.space", HF_SPACE_KEY=chave)
        payload = {**json.loads(evento()["body"]), "relato": chave}
        cliente = MagicMock()
        cliente.open.side_effect = ValueError(chave)
        with patch.object(fn.urllib.request, "build_opener", return_value=cliente):
            with patch.object(fn, "gravar_ocorrencia", return_value=(73, datetime.now(timezone.utc))):
                with self.assertLogs(fn.logger, level="INFO") as logs:
                    fn.lambda_handler(evento(payload=payload), None)
        self.assertIn("omitido=conteudo_sensivel", " ".join(logs.output))
        self.assertNotIn(chave, " ".join(logs.output))

    def test_huggingface_malformada_e_fallback(self):
        os.environ["HF_TOKEN"] = "token-ficticio"
        resposta = MagicMock()
        resposta.__enter__.return_value = resposta
        with patch.object(fn, "_analisar_comprehend", side_effect=RuntimeError()):
            with patch.object(fn.urllib.request, "urlopen", return_value=resposta) as chamada:
                for invalida in ({"error": "modelo indisponivel"}, [], [[{"label": "negative", "score": float("nan")}]], ["x"]):
                    resposta.read.return_value = json.dumps(invalida).encode()
                    self.assertEqual(fn.analisar_relato("Relato sintetico"), (None, None))
                resposta.read.return_value = b'[[{"label":"negative","score":0.91},{"label":"neutral","score":0.09}]]'
                self.assertEqual(fn.analisar_relato("Relato sintetico"), ("negative", 0.91))
        self.assertEqual(chamada.call_args.kwargs["timeout"], 4)

    def test_comprehend_pt_timeout_e_resultado(self):
        boto = MagicMock()
        config = MagicMock()
        boto.client.return_value.detect_sentiment.return_value = {
            "Sentiment": "NEGATIVE", "SentimentScore": {"Negative": 0.93456},
        }
        with patch.dict(sys.modules, {"boto3": boto, "botocore.config": SimpleNamespace(Config=config)}):
            self.assertEqual(fn._analisar_comprehend("Relato de teste"), ("negative", 0.9346))
        boto.client.return_value.detect_sentiment.assert_called_once_with(Text="Relato de teste", LanguageCode="pt")
        self.assertEqual(config.call_args.kwargs["retries"], {"total_max_attempts": 1})

    def test_sucesso_ia_simulada_persiste_e_consulta_mesmos_resultados(self):
        payload = {**json.loads(evento()["body"]), "relato": "Relato ficticio: agua na passagem"}
        conn = MagicMock()
        momento = datetime.now(timezone.utc)
        conn.cursor.return_value.fetchone.return_value = (57, momento)
        with patch.object(fn, "_analisar_comprehend", return_value=("negative", 0.93)):
            with patch.object(fn, "conectar", return_value=conn):
                retorno = fn.lambda_handler(evento(payload=payload), None)
        dados = json.loads(retorno["body"])
        self.assertEqual(retorno["statusCode"], 201)
        self.assertEqual((dados["sentimento"], dados["confianca"], dados["id"]), ("negative", 0.93, 57))
        parametros = conn.cursor.return_value.execute.call_args.args[1]
        gravado = dict(zip(fn.COLUNAS_OCORRENCIA, parametros))
        self.assertEqual((gravado["sentimento"], gravado["confianca"]), ("negative", 0.93))
        linha = (57, *(gravado[c] for c in fn.COLUNAS_OCORRENCIA[:-1]), momento)
        conn.cursor.return_value.fetchall.return_value = [linha]
        with patch.object(fn, "conectar", return_value=conn):
            consulta = fn.lambda_handler(evento("GET", "/ocorrencias"), None)
        consultado = json.loads(consulta["body"])["ocorrencias"][0]
        self.assertEqual((consultado["sentimento"], consultado["confianca"], consultado["id"]), ("negative", 0.93, 57))

    def test_huggingface_endpoint_modelo_urllib_e_maior_pontuacao(self):
        os.environ.update(AI_PROVIDER="huggingface", HF_TOKEN="token-ficticio")
        retorno = MagicMock()
        retorno.__enter__.return_value = retorno
        retorno.read.return_value = b'[[{"label":"neutral","score":0.50001},{"label":"positive","score":0.50002}]]'
        with patch.object(fn.urllib.request, "urlopen", return_value=retorno) as chamada:
            with patch.object(fn, "_analisar_comprehend") as comprehend:
                self.assertEqual(fn.analisar_relato("Relato ficticio"), ("positive", 0.5))
        req = chamada.call_args.args[0]
        self.assertEqual(req.full_url, "https://router.huggingface.co/hf-inference/models/cardiffnlp/twitter-xlm-roberta-base-sentiment")
        self.assertEqual(req.method, "POST")
        self.assertEqual(json.loads(req.data), {"inputs": "Relato ficticio"})
        self.assertEqual(req.get_header("Authorization"), "Bearer token-ficticio")
        comprehend.assert_not_called()

    def test_huggingface_sem_token_ou_provedor_invalido_avisa_sem_rede(self):
        with patch.object(fn.urllib.request, "urlopen") as chamada:
            for provedor, motivo in (("huggingface", "token_nao_configurado"),
                                     ("desconhecido", "provedor_nao_suportado")):
                os.environ["AI_PROVIDER"] = provedor
                with self.assertLogs(fn.logger, level="WARNING") as logs:
                    self.assertEqual(fn.analisar_relato("Relato ficticio"), (None, None))
                self.assertIn(motivo, " ".join(logs.output))
        chamada.assert_not_called()

    def test_fronteiras_http_alerta_e_warning_critico(self):
        padrao = json.loads(evento()["body"])
        for valor, risco, alerta in ((149.99, "normal", False), (150, "atencao", False),
                                    (249.99, "atencao", False), (250, "critico", True)):
            with self.subTest(valor=valor):
                with patch.object(fn, "gravar_ocorrencia", return_value=(11, datetime.now(timezone.utc))):
                    with self.assertLogs(fn.logger, level="INFO") as logs:
                        retorno = fn.lambda_handler(evento(payload={**padrao, "valor": valor, "evento_id": "teste-fronteira"}), None)
                self.assertEqual(retorno["statusCode"], 201)
                self.assertEqual((json.loads(retorno["body"])["nivel_risco"], json.loads(retorno["body"])["alerta"]), (risco, alerta))
                criticos = [r for r in logs.records if r.levelname == "WARNING" and "ALERTA CIDADAO" in r.getMessage()]
                self.assertEqual(bool(criticos), alerta)
                if alerta:
                    self.assertIn("evento_id=teste-fronteira", criticos[0].getMessage())

    def test_logs_corpo_literal_dados_classificacao_e_gravacao_sem_credenciais(self):
        payload = {**json.loads(evento()["body"]), "relato": "Relato ficticio: agua na passagem", "evento_id": "teste-log-01"}
        ev = evento(payload=payload)
        ev["body"] = json.dumps(payload, indent=2)
        with patch.object(fn, "analisar_relato", return_value=("negative", 0.9)):
            with patch.object(fn, "gravar_ocorrencia", return_value=(7, datetime.now(timezone.utc))):
                with self.assertLogs(fn.logger, level="INFO") as logs:
                    fn.lambda_handler(ev, None)
        texto = " ".join(logs.output)
        self.assertIn("CORPO RECEBIDO", texto)
        self.assertIn("DADOS INTERPRETADOS", texto)
        self.assertIn("CLASSIFICACAO", texto)
        self.assertIn("GRAVADO NO RDS id=7", texto)
        self.assertNotIn("chave-ficticia-local", texto)
        self.assertIn(payload["relato"], texto)
        corpo = next(r.getMessage() for r in logs.records if r.getMessage().startswith("CORPO RECEBIDO bruto="))
        self.assertEqual(json.loads(corpo.split("bruto=", 1)[1]), ev["body"])
        self.assertTrue(all("\n" not in r.getMessage() and "\r" not in r.getMessage() for r in logs.records))
        self.assertIn("evento_id=teste-log-01", texto)

    def test_log_corpo_base64_decodifica_utf8_sem_injetar_linhas(self):
        payload = {**json.loads(evento()["body"]), "relato": "Relato fictício\nágua subindo\r\tna passagem"}
        bruto = json.dumps(payload, ensure_ascii=False, indent=2)
        ev = evento(payload=payload)
        ev.update(body=base64.b64encode(bruto.encode("utf-8")).decode("ascii"), isBase64Encoded=True)
        with patch.object(fn, "analisar_relato", return_value=("negative", 0.9)), patch.object(fn, "gravar_ocorrencia", return_value=(7, datetime.now(timezone.utc))):
            with self.assertLogs(fn.logger, level="INFO") as logs:
                self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 201)
        registro = next(r.getMessage() for r in logs.records if r.getMessage().startswith("CORPO RECEBIDO bruto="))
        self.assertEqual(json.loads(registro.split("bruto=", 1)[1]), bruto)
        self.assertNotIn("\n", registro)

    def test_logs_invalidos_tem_corpo_e_warning_correlacionado(self):
        payload = {"evento_id": "teste-descarte-01", "metrica": "nivel_rio_cm", "valor": 280,
                   "relato": "Relato ficticio descartado"}
        with self.assertLogs(fn.logger, level="INFO") as logs:
            self.assertEqual(fn.lambda_handler(evento(payload=payload), None)["statusCode"], 400)
        self.assertIn(payload["relato"], logs.output[1])
        self.assertTrue(any(r.levelname == "WARNING" and "evento_id=teste-descarte-01" in r.getMessage() for r in logs.records))
        with self.assertLogs(fn.logger, level="INFO") as logs:
            ev = evento()
            ev["body"] = '{"relato": "Relato ficticio",'
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)
        self.assertIn("CORPO RECEBIDO bruto=", " ".join(logs.output))

    def test_logs_omitem_corpo_com_credenciais_e_detalhes_de_erros(self):
        padrao = json.loads(evento()["body"])
        os.environ["HF_TOKEN"] = "segredo-hf-ficticio"
        for extra in ({"password": "segredo-nunca-logar"}, {"nested": {"HF_TOKEN": "segredo-nunca-logar"}},
                      {"relato": "segredo-hf-ficticio"}, {"relato": "chave-ficticia-local"}):
            with self.subTest(extra=extra):
                with patch.object(fn, "analisar_relato", side_effect=RuntimeError("segredo-nunca-logar")):
                    with self.assertLogs(fn.logger, level="INFO") as logs:
                        fn.lambda_handler(evento(payload={**padrao, **extra}), None)
                texto = " ".join(logs.output)
                self.assertIn("CORPO RECEBIDO omitido=conteudo_sensivel", texto)
                for segredo in ("segredo-nunca-logar", "segredo-hf-ficticio", "chave-ficticia-local"):
                    self.assertNotIn(segredo, texto)

    def test_log_limite_excedido_nao_inclui_corpo(self):
        ev = evento()
        ev["body"] = "NAO REGISTRAR" * 2000
        with self.assertLogs(fn.logger, level="INFO") as logs:
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)
        texto = " ".join(logs.output)
        self.assertIn("CORPO RECEBIDO omitido=limite_excedido", texto)
        self.assertNotIn("NAO REGISTRAR", texto)

    def test_logs_nao_vazam_chave_copiada_em_campos_do_contrato(self):
        padrao = json.loads(evento()["body"])
        for campo in ("evento_id", "ponto_id", "tipo"):
            with self.subTest(campo=campo):
                with patch.object(fn, "gravar_ocorrencia", return_value=(7, datetime.now(timezone.utc))):
                    with self.assertLogs(fn.logger, level="INFO") as logs:
                        self.assertEqual(fn.lambda_handler(evento(payload={**padrao, campo: "chave-ficticia-local"}), None)["statusCode"], 201)
                self.assertNotIn("chave-ficticia-local", " ".join(logs.output))

    def test_erro_banco_nao_vaza_detalhes(self):
        with patch.object(fn, "gravar_ocorrencia", side_effect=RuntimeError("senha=SEGREDO banco privado")):
            r = fn.lambda_handler(evento(), None)
        self.assertEqual(r["statusCode"], 500)
        self.assertNotIn("SEGREDO", r["body"])
        self.assertNotIn("banco privado", r["body"])

    def test_get_ocorrencias_protegido(self):
        with patch.object(fn, "listar_ocorrencias", return_value=[]) as db:
            self.assertEqual(fn.lambda_handler(evento("GET", autorizado=False), None)["statusCode"], 401)
            db.assert_not_called()
            self.assertEqual(fn.lambda_handler(evento("GET"), None)["statusCode"], 200)
            db.assert_called_once_with(20)

    def test_persistencia_parametrizada_e_conexao_fechada(self):
        conn = MagicMock()
        conn.cursor.return_value.fetchone.return_value = (17, datetime.now(timezone.utc))
        dados = {c: None for c in fn.COLUNAS_OCORRENCIA}
        dados["relato"] = "'); DROP TABLE ocorrencias; --"
        with patch.object(fn, "conectar", return_value=conn):
            self.assertEqual(fn.gravar_ocorrencia(dados)[0], 17)
        sql, parametros = conn.cursor.return_value.execute.call_args.args
        self.assertNotIn(dados["relato"], sql)
        self.assertIn(dados["relato"], parametros)
        conn.commit.assert_called_once()
        conn.close.assert_called_once()

    def test_idempotencia_e_conflito(self):
        conn = MagicMock()
        momento = datetime.now(timezone.utc)
        dados = {"evento_id": "evento-1", "payload_hash": "hash-1"}
        conn.cursor.return_value.fetchone.side_effect = [None, (17, momento, "hash-1")]
        with patch.object(fn, "conectar", return_value=conn):
            self.assertEqual(fn.gravar_ocorrencia(dados), (17, momento))
        conn.cursor.return_value.fetchone.side_effect = [None, (17, momento, "outro-hash")]
        with patch.object(fn, "conectar", return_value=conn):
            with self.assertRaises(fn.ConflitoEvento):
                fn.gravar_ocorrencia(dados)
        with patch.object(fn, "gravar_ocorrencia", side_effect=fn.ConflitoEvento()):
            self.assertEqual(fn.lambda_handler(evento(), None)["statusCode"], 409)

    def test_tls_verifica_certificado_e_timeout(self):
        os.environ.update(DB_HOST="rds.local", DB_NAME="citizentech", DB_USER="teste", DB_PASSWORD="ficticio")
        driver = MagicMock()
        with patch.dict(sys.modules, {"pg8000": driver}):
            fn.conectar()
        config = driver.connect.call_args.kwargs
        self.assertEqual(config["timeout"], 8)
        self.assertTrue(config["ssl_context"].check_hostname)
        self.assertEqual(config["ssl_context"].verify_mode, fn.ssl.CERT_REQUIRED)

    def test_paginacao_publica_tem_cursor_e_lacunas(self):
        conn = MagicMock()
        conn.cursor.return_value.fetchall.return_value = [linha_historica(0), linha_historica(1), linha_historica(2)]
        with patch.object(fn, "conectar", return_value=conn):
            r = fn.lambda_handler(evento("GET", "/dados", autorizado=False, query={"limit": "2"}), None)
        corpo = json.loads(r["body"])
        self.assertEqual(r["statusCode"], 200)
        self.assertEqual(corpo["quantidade"], 2)
        self.assertEqual(corpo["proximo_cursor"], "2024-05-06T05:00:00Z")
        self.assertIsNone(corpo["dados"][0]["chuva_acum_3h"])
        self.assertNotIn("relato", corpo["dados"][0])
        sql, parametros = conn.cursor.return_value.execute.call_args.args
        self.assertIn("base_historica", sql)
        self.assertEqual(parametros, ("1000480", 3))

    def test_cursor_e_filtros_utc_parametrizados(self):
        conn = MagicMock()
        conn.cursor.return_value.fetchall.return_value = []
        parametros = {"inicio": "2024-05-06T01:00:00-03:00", "fim": "2024-05-07T01:00:00-03:00", "cursor": "2024-05-06T05:00:00Z"}
        with patch.object(fn, "conectar", return_value=conn):
            linhas, cursor = fn.consultar_historico(parametros)
        self.assertEqual((linhas, cursor), ([], None))
        sql, args = conn.cursor.return_value.execute.call_args.args
        self.assertIn("medido_em > %s", sql)
        self.assertEqual(args[1], datetime(2024, 5, 6, 4, tzinfo=timezone.utc))
        self.assertEqual(args[-1], 101)

    def test_consultas_invalidas_400_antes_banco(self):
        casos = [
            {"limit": "0"}, {"limit": "1001"}, {"limit": "1;drop"},
            {"cursor": "2024-05-06T04:00:00"}, {"estacao_id": "outra"},
            {"inicio": "2025-01-01T00:00:00Z", "fim": "2024-01-01T00:00:00Z"},
            {"desconhecido": "1"},
        ]
        with patch.object(fn, "conectar") as db:
            for consulta in casos:
                with self.subTest(consulta=consulta):
                    self.assertEqual(fn.lambda_handler(evento("GET", "/dados", query=consulta), None)["statusCode"], 400)
            ev = evento("GET", "/dados")
            ev["rawQueryString"] = "limit=1&limit=2"
            self.assertEqual(fn.lambda_handler(ev, None)["statusCode"], 400)
        db.assert_not_called()

    def test_csv_publico_colunas_originais_sem_pii(self):
        conn = MagicMock()
        conn.cursor.return_value.fetchall.return_value = [linha_historica()]
        with patch.object(fn, "conectar", return_value=conn):
            r = fn.lambda_handler(evento("GET", "/dados.csv", autorizado=False), None)
        self.assertEqual(r["statusCode"], 200)
        self.assertIn("text/csv", r["headers"]["Content-Type"])
        self.assertIn("base_sp_aguas_tratada.csv", r["headers"]["Content-Disposition"])
        linhas = list(csv.DictReader(io.StringIO(r["body"])))
        self.assertEqual(tuple(linhas[0]), fn.COLUNAS_CSV)
        self.assertEqual(linhas[0]["chuva_acum_3h"], "")
        self.assertEqual(linhas[0]["datahora"], "2024-05-06 01:00:00")
        self.assertNotIn("relato", r["body"])
        self.assertEqual(conn.cursor.return_value.execute.call_args.args[1][-1], 30001)

    def test_serializacao_decimal_e_datetime(self):
        corpo = json.loads(fn.resposta(200, {"confianca": Decimal("0.9000"), "hora": datetime(2026, 11, 10, tzinfo=timezone.utc)})["body"])
        self.assertEqual(corpo, {"confianca": 0.9, "hora": "2026-11-10T00:00:00Z"})


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""
CitizenTech - Sprint 4
Simulador de dispositivo de campo (ESP32 ou drone) enviando leituras
para a Function URL da Lambda.

Nao precisa de hardware: o script faz o mesmo POST que o ESP32 faria.
Usa apenas a biblioteca padrao do Python.

Uso:
    # PowerShell: chave fornecida separadamente; nao vai no codigo nem na URL.
    $env:FUNCTION_URL="https://xxxx.lambda-url.us-east-1.on.aws"
    $env:DEVICE_KEY="sua-chave-de-teste"

    # 10 leituras normais de um sensor de nivel de rio
    python3 simulador_dispositivo.py

    # cenario de enchente: o valor sobe a cada leitura ate virar critico
    python3 simulador_dispositivo.py --cenario enchente --leituras 8

    # drone sobrevoando area de queimada, com relato de texto
    python3 simulador_dispositivo.py --tipo drone --cenario queimada

    # uma leitura unica, para o print da entrega
    python3 simulador_dispositivo.py --leituras 1
"""

import argparse
import json
import math
import os
import random
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

CENARIOS = {
    "normal": {
        "metrica": "nivel_rio_cm",
        "inicio": 80.0,
        "passo": 3.0,
        "ruido": 5.0,
        "relatos": [
            "Rio esta no nivel de sempre, tudo tranquilo por aqui",
            "Passei na ponte agora, sem novidade",
        ],
    },
    "enchente": {
        "metrica": "nivel_rio_cm",
        "inicio": 120.0,
        "passo": 36.0,
        "ruido": 8.0,
        "relatos": [
            "A agua subiu muito rapido, ja cobriu a calcada",
            "Moradores da rua de baixo estao tirando os moveis",
            "Nao da mais para passar de carro, esta alagado",
        ],
    },
    "queimada": {
        "metrica": "fumaca_ppm",
        "inicio": 180.0,
        "passo": 95.0,
        "ruido": 25.0,
        "relatos": [
            "Muita fumaca vindo do lado da plantacao",
            "O ar esta irrespiravel, criancas tossindo na escola",
        ],
    },
    "seca": {
        "metrica": "umidade_solo_pct",
        "inicio": 38.0,
        "passo": -6.0,
        "ruido": 2.0,
        "relatos": [
            "Plantacao comecando a murchar, nao chove ha semanas",
            "Terra totalmente rachada no talhao 3",
        ],
    },
}

def enviar(url, payload, tempo_limite=30, device_key=None):
    chave = device_key or os.environ.get("DEVICE_KEY")
    if not isinstance(chave, str) or not chave.strip():
        raise ValueError("Defina DEVICE_KEY antes de enviar leituras")
    if not chave.isascii() or any(ord(caractere) < 32 or ord(caractere) > 126 for caractere in chave):
        raise ValueError("DEVICE_KEY possui caracteres invalidos para cabecalho HTTP")
    corpo = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url.rstrip("/") + "/ocorrencias",
        data=corpo,
        headers={"Content-Type": "application/json",
                 "User-Agent": "Travessia-Alerta-Simulador/1.0",
                 "X-Device-Key": chave},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=tempo_limite) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as erro:
        return erro.code, erro.read().decode("utf-8", "replace")
    except Exception as erro:
        return None, "Falha de conexao ou resposta invalida (" + type(erro).__name__ + ")"


def classificar_nivel(valor):
    if valor >= 250:
        return "critico"
    if valor >= 150:
        return "atencao"
    return "normal"


def montar_payload(dispositivo_id, ponto_id, tipo, metrica, valor, movimento=None):
    payload = {
        "evento_id": "ta-simulador-" + uuid4().hex,
        "ponto_id": ponto_id,
        "dispositivo_id": dispositivo_id,
        "tipo_dispositivo": tipo,
        "origem": "simulador",
        "metrica": metrica,
        "valor": valor,
        "medido_em": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    if metrica == "nivel_rio_cm":
        payload["distancia_cm"] = round(max(0.0, 300.0 - valor), 1)
        payload["status_nivel"] = classificar_nivel(valor)
    if movimento is not None:
        payload["movimento"] = movimento
        payload["status_pir"] = "movimento" if movimento else "sem_movimento"
    return payload


def main(argv=None):
    p = argparse.ArgumentParser(description="Simulador de ESP32/drone - CitizenTech")
    p.add_argument("--url", default=os.environ.get("FUNCTION_URL"),
                   help="Function URL da Lambda (ou variavel FUNCTION_URL)")
    p.add_argument("--cenario", default="normal", choices=list(CENARIOS),
                   help="comportamento da serie de leituras")
    p.add_argument("--tipo", default="esp32", choices=["esp32", "drone", "app"],
                   help="tipo de dispositivo que aparece no log")
    p.add_argument("--dispositivo-id", help="identidade vinculada a DEVICE_KEY; padrao esp32-travessia-01")
    p.add_argument("--ponto-id", default="travessia-01")
    p.add_argument("--credenciais", type=Path,
                   help="carrega explicitamente DEVICE_KEY e DEVICE_ID de um JSON local privado")
    movimento = p.add_mutually_exclusive_group()
    movimento.add_argument("--movimento", action="store_const", const=True, dest="movimento",
                          help="simula o PIR detectando aproximacao")
    movimento.add_argument("--sem-movimento", action="store_const", const=False, dest="movimento",
                          help="simula o PIR sem detectar aproximacao")
    p.set_defaults(movimento=None)
    p.add_argument("--leituras", type=int, default=10, help="quantas leituras enviar")
    p.add_argument("--intervalo", type=float, default=2.0,
                   help="segundos entre as leituras")
    p.add_argument("--sem-relato", action="store_true",
                   help="envia so telemetria, sem texto para a IA classificar")
    args = p.parse_args(argv)

    credenciais = {}
    if args.credenciais:
        try:
            credenciais = json.loads(args.credenciais.read_text(encoding="utf-8-sig"))
            if not isinstance(credenciais, dict):
                raise ValueError("formato invalido")
            if not args.url:
                args.url = credenciais.get("FUNCTION_URL")
            if not args.url and Path("deployment.json").exists():
                deployment = json.loads(Path("deployment.json").read_text(encoding="utf-8-sig"))
                for campo in ("function_name", "region"):
                    if credenciais.get(campo) and credenciais[campo] != deployment.get(campo):
                        raise ValueError("deployment.json pertence a outra funcao/regiao")
                args.url = deployment.get("function_url")
        except (OSError, ValueError, TypeError, AttributeError):
            print("Nao foi possivel ler as credenciais/deployment locais ou os projetos divergem.",
                  file=sys.stderr)
            return 1

    chave = os.environ.get("DEVICE_KEY") or credenciais.get("DEVICE_KEY")
    if not isinstance(chave, str) or not chave.strip():
        print("Defina DEVICE_KEY ou use --credenciais .local/credenciais.json.", file=sys.stderr)
        return 1
    if not chave.isascii() or any(ord(caractere) < 32 or ord(caractere) > 126 for caractere in chave):
        print("DEVICE_KEY possui caracteres invalidos para cabecalho HTTP.", file=sys.stderr)
        return 1
    dispositivo = (args.dispositivo_id or os.environ.get("DEVICE_ID")
                   or credenciais.get("DEVICE_ID") or "esp32-travessia-01")

    if not args.url:
        print("Defina FUNCTION_URL ou informe --url https://....on.aws", file=sys.stderr)
        return 1
    if args.leituras < 1 or not math.isfinite(args.intervalo) or args.intervalo < 0:
        print("--leituras deve ser positivo e --intervalo deve ser zero ou positivo.", file=sys.stderr)
        return 1

    cen = CENARIOS[args.cenario]
    valor = cen["inicio"]

    print(f"Dispositivo .....: {dispositivo} ({args.tipo})")
    print(f"Ponto ...........: {args.ponto_id}")
    print(f"Cenario .........: {args.cenario} / metrica {cen['metrica']}")
    print(f"Destino .........: {args.url.rstrip('/')}/ocorrencias")
    print("-" * 72)

    for i in range(1, args.leituras + 1):
        leitura = round(max(0.0, valor + random.uniform(-cen["ruido"], cen["ruido"])), 1)
        payload = montar_payload(dispositivo, args.ponto_id, args.tipo, cen["metrica"],
                                 leitura, args.movimento)
        # O relato e o texto que o modelo de IA vai classificar.
        if not args.sem_relato and (i == 1 or i == args.leituras or random.random() < 0.4):
            payload["relato"] = random.choice(cen["relatos"])

        status, resposta = enviar(args.url, payload, device_key=chave)
        print(f"[{i:02d}/{args.leituras}] POST {cen['metrica']}={leitura} -> HTTP {status}")
        print("         enviado=" + json.dumps(payload, ensure_ascii=False))
        if isinstance(resposta, dict):
            print(f"         id={resposta.get('id')} "
                  f"risco={resposta.get('nivel_risco')} "
                  f"sentimento={resposta.get('sentimento')} "
                  f"confianca={resposta.get('confianca')}"
                  + ("  << ALERTA" if resposta.get("alerta") else ""))
        else:
            print(f"         resposta: {resposta}")
        if status != 201:
            print("Envio interrompido: a API nao confirmou a criacao da leitura.", file=sys.stderr)
            return 1

        valor += cen["passo"]
        if i < args.leituras:
            time.sleep(args.intervalo)

    print("-" * 72)
    print("Fim do envio. Abra o CloudWatch Logs da funcao para ver as linhas")
    print("CORPO RECEBIDO / DADOS INTERPRETADOS / CLASSIFICACAO / GRAVADO NO RDS.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

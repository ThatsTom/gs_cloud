"""Valida e importa o CSV real da SP Aguas em tabela propria no RDS.

Validar sem AWS: python importar_base.py --validar
Importar: defina DB_HOST, DB_NAME, DB_USER e DB_PASSWORD e execute o script.
Dependencias da importacao: pg8000; no Windows, tzdata para America/Sao_Paulo.
O arquivo nao e enviado ao endpoint de ocorrencias e os alvos nao sao refeitos.
"""

import argparse
import csv
import hashlib
import json
import math
import os
import re
import ssl
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


COLUNAS_CSV = (
    "datahora", "chuva_mm_1h", "chuva_acum_3h", "chuva_acum_6h",
    "chuva_acum_24h", "chuva_acum_72h", "nivel_cm", "nivel_max_cm",
    "variacao_nivel_1h", "variacao_nivel_3h", "hora", "mes",
    "acima_limiar", "ultrapassa_3h",
)
COLUNAS_NUMERICAS = COLUNAS_CSV[1:10]
COLUNAS_BANCO = (
    "estacao_id", "medido_em", *COLUNAS_CSV, "origem", "arquivo_sha256",
)
ORIGEM = "sp_aguas_sibh"
FUSO_ORIGEM = "America/Sao_Paulo"
SQL_CRIACAO = Path(__file__).with_name("base_historica.sql")


def fuso_sao_paulo():
    try:
        return ZoneInfo(FUSO_ORIGEM)
    except ZoneInfoNotFoundError as erro:
        raise ValueError(
            "Fuso America/Sao_Paulo indisponivel; instale: python -m pip install tzdata"
        ) from erro


def _numero(texto, coluna):
    if not texto.strip():
        return None
    try:
        valor = float(texto)
    except (TypeError, ValueError) as erro:
        raise ValueError(f"{coluna}: numero invalido") from erro
    if not math.isfinite(valor):
        raise ValueError(f"{coluna}: NaN e infinito nao sao permitidos; use campo vazio")
    return valor


def _inteiro(texto, coluna, minimo, maximo, obrigatorio=False):
    if not texto.strip() and not obrigatorio:
        return None
    if not re.fullmatch(r"[0-9]+", texto.strip()):
        raise ValueError(f"{coluna}: inteiro invalido")
    valor = int(texto)
    if not minimo <= valor <= maximo:
        raise ValueError(f"{coluna}: deve estar entre {minimo} e {maximo}")
    return valor


def converter_linha(linha, estacao_id, arquivo_sha256, fuso):
    """Conserva campos vazios como None e acrescenta a hora UTC correspondente."""
    try:
        datahora = datetime.strptime(linha["datahora"], "%Y-%m-%d %H:%M:%S")
    except (TypeError, ValueError) as erro:
        raise ValueError("datahora: esperado YYYY-MM-DD HH:MM:SS sem offset") from erro
    if datahora.minute or datahora.second:
        raise ValueError("datahora: a base deve estar agregada em horas inteiras")
    local = datahora.replace(tzinfo=fuso)
    if local.utcoffset() != local.replace(fold=1).utcoffset():
        raise ValueError("datahora: hora local ambigua ou inexistente")
    medido_em = local.astimezone(timezone.utc)
    if medido_em.astimezone(fuso).replace(tzinfo=None) != datahora:
        raise ValueError("datahora: hora local inexistente")
    dados = {"estacao_id": estacao_id, "medido_em": medido_em, "datahora": datahora}
    dados.update({coluna: _numero(linha[coluna], coluna) for coluna in COLUNAS_NUMERICAS})
    dados["hora"] = _inteiro(linha["hora"], "hora", 0, 23, obrigatorio=True)
    dados["mes"] = _inteiro(linha["mes"], "mes", 1, 12, obrigatorio=True)
    if dados["hora"] != datahora.hour or dados["mes"] != datahora.month:
        raise ValueError("hora ou mes diverge de datahora")
    for coluna in ("acima_limiar", "ultrapassa_3h"):
        dados[coluna] = _inteiro(linha[coluna], coluna, 0, 1)
    dados.update(origem=ORIGEM, arquivo_sha256=arquivo_sha256)
    return dados


def ler_base(caminho, estacao_id="1000480", fuso=None):
    """Valida todo o CSV antes de conectar ao banco; devolve linhas e relatorio."""
    caminho = Path(caminho)
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", estacao_id):
        raise ValueError("estacao_id deve ter de 1 a 64 letras, numeros, _ ou -")
    fuso = fuso if fuso is not None else fuso_sao_paulo()
    arquivo_sha256 = hashlib.sha256(caminho.read_bytes()).hexdigest()
    linhas = []
    vazios = dict.fromkeys(COLUNAS_CSV, 0)
    horas_sem_linha = 0
    ultima_hora = None
    with caminho.open(encoding="utf-8-sig", newline="") as arquivo:
        leitor = csv.DictReader(arquivo)
        if (
            leitor.fieldnames is None
            or len(leitor.fieldnames) != len(COLUNAS_CSV)
            or set(leitor.fieldnames) != set(COLUNAS_CSV)
        ):
            raise ValueError("Cabecalho diferente do contrato: " + ",".join(COLUNAS_CSV))
        for numero_linha, linha in enumerate(leitor, start=2):
            try:
                if None in linha or any(valor is None for valor in linha.values()):
                    raise ValueError("quantidade de campos diferente do cabecalho")
                dados = converter_linha(linha, estacao_id, arquivo_sha256, fuso)
                if ultima_hora is not None:
                    intervalo = dados["medido_em"] - ultima_hora
                    if intervalo <= timedelta(0):
                        raise ValueError("datahora repetida ou fora da ordem cronologica")
                    horas_sem_linha += max(0, int(intervalo.total_seconds() / 3600) - 1)
                ultima_hora = dados["medido_em"]
                for coluna in COLUNAS_CSV:
                    vazios[coluna] += dados[coluna] is None
                linhas.append(dados)
            except ValueError as erro:
                raise ValueError(f"Linha {numero_linha}: {erro}") from erro
    if not linhas:
        raise ValueError("CSV sem linhas de dados")
    relatorio = {
        "arquivo": caminho.name,
        "arquivo_sha256": arquivo_sha256,
        "estacao_id": estacao_id,
        "origem": ORIGEM,
        "fuso_original": FUSO_ORIGEM,
        "linhas": len(linhas),
        "inicio_local": linhas[0]["datahora"].isoformat(sep=" "),
        "fim_local": linhas[-1]["datahora"].isoformat(sep=" "),
        "inicio_utc": linhas[0]["medido_em"].isoformat(),
        "fim_utc": linhas[-1]["medido_em"].isoformat(),
        "horas_sem_linha": horas_sem_linha,
        "campos_vazios": vazios,
        "linhas_com_chuva_e_nivel": sum(
            linha["chuva_mm_1h"] is not None and linha["nivel_cm"] is not None
            for linha in linhas
        ),
    }
    return linhas, relatorio


def conectar():
    """Exige TLS com certificado e hostname verificados; nunca imprime a senha."""
    try:
        import pg8000.dbapi as driver
    except ImportError as erro:
        raise ValueError("Instale a dependencia: python -m pip install pg8000") from erro
    obrigatorias = ("DB_HOST", "DB_NAME", "DB_USER", "DB_PASSWORD")
    ausentes = [nome for nome in obrigatorias if not os.environ.get(nome)]
    if ausentes:
        raise ValueError("Variaveis de ambiente ausentes: " + ", ".join(ausentes))
    # DB_CA_FILE permite o bundle oficial do RDS, sem desligar a verificacao.
    contexto_tls = ssl.create_default_context(cafile=os.environ.get("DB_CA_FILE") or None)
    return driver.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "5432")),
        database=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        ssl_context=contexto_tls,
        timeout=15,
    )


def importar(linhas, conectar_banco=conectar, tamanho_lote=500):
    """Cria tabela e faz UPSERT atomico; repetir o arquivo nao duplica as horas."""
    if tamanho_lote < 1:
        raise ValueError("tamanho_lote deve ser positivo")
    if not linhas:
        raise ValueError("Nao ha linhas para importar")
    colunas = ", ".join(COLUNAS_BANCO)
    marcadores = ", ".join(["%s"] * len(COLUNAS_BANCO))
    atualizaveis = [c for c in COLUNAS_BANCO if c not in ("estacao_id", "medido_em")]
    atualizacoes = ", ".join(f"{c} = EXCLUDED.{c}" for c in atualizaveis)
    comando = (
        f"INSERT INTO base_historica ({colunas}) VALUES ({marcadores}) "
        f"ON CONFLICT (estacao_id, medido_em) DO UPDATE SET {atualizacoes}"
    )
    conexao = conectar_banco()
    try:
        cursor = conexao.cursor()
        # Arquivo contem apenas DDL, sem consultas de demonstracao.
        for instrucao in SQL_CRIACAO.read_text(encoding="utf-8").split(";"):
            if instrucao.strip():
                cursor.execute(instrucao)
        for inicio in range(0, len(linhas), tamanho_lote):
            lote = linhas[inicio:inicio + tamanho_lote]
            cursor.executemany(comando, [tuple(linha[c] for c in COLUNAS_BANCO) for linha in lote])
        cursor.execute(
            "SELECT COUNT(*) FROM base_historica WHERE estacao_id = %s AND arquivo_sha256 = %s",
            (linhas[0]["estacao_id"], linhas[0]["arquivo_sha256"]),
        )
        total_confirmado = cursor.fetchone()[0]
        if total_confirmado != len(linhas):
            raise ValueError("Contagem no banco diverge do arquivo; transacao cancelada")
        conexao.commit()
        return {"linhas_processadas": len(linhas), "linhas_confirmadas_no_banco": total_confirmado}
    except Exception:
        conexao.rollback()
        raise
    finally:
        conexao.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arquivo", nargs="?", default="base_sp_aguas_tratada.csv")
    parser.add_argument("--estacao-id", default="1000480")
    parser.add_argument("--validar", "--dry-run", action="store_true", dest="validar",
                        help="valida e descreve o arquivo sem abrir conexao com a AWS")
    parser.add_argument("--tamanho-lote", type=int, default=500)
    args = parser.parse_args(argv)
    try:
        linhas, relatorio = ler_base(args.arquivo, args.estacao_id)
        if args.validar:
            relatorio["modo"] = "validacao_local_sem_banco"
        else:
            relatorio.update(importar(linhas, tamanho_lote=args.tamanho_lote))
            relatorio["modo"] = "importacao_rds_confirmada"
        print(json.dumps(relatorio, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError) as erro:
        print(f"Erro: {erro}", file=sys.stderr)
        return 1
    except Exception as erro:
        # Erros de driver podem conter detalhes de conexao: exponha so o tipo.
        print(f"Importacao cancelada ({type(erro).__name__}); confira conexao, TLS e permissoes.",
              file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

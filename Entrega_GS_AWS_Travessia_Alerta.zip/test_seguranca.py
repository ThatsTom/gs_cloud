"""Testes locais da autenticacao; usam somente credenciais ficticias."""

import json
import os
import unittest
from unittest.mock import patch

import seguranca


class SegurancaTests(unittest.TestCase):
    def setUp(self):
        self.ambiente = patch.dict(os.environ, {}, clear=True)
        self.ambiente.start()
        self.addCleanup(self.ambiente.stop)
        os.environ["DEVICE_KEYS_JSON"] = json.dumps({
            "esp32-travessia-01": "chave-ficticia-sensor-01",
            "esp32-travessia-02": "chave-ficticia-sensor-02",
        })
        self.headers = {"X-Device-Key": "chave-ficticia-sensor-01"}

    def test_chave_correta_autoriza_identidade(self):
        self.assertTrue(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))

    def test_chave_nao_autoriza_outro_dispositivo(self):
        self.assertFalse(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-02"))
        self.assertFalse(seguranca.autenticar_dispositivo(self.headers, "desconhecido"))

    def test_ausente_errada_e_tipos_invalidos_negam(self):
        for headers in ({}, None, [], {"X-Device-Key": "errada"}, {"X-Device-Key": 123}):
            with self.subTest(headers=headers):
                self.assertFalse(seguranca.autenticar_dispositivo(headers, "esp32-travessia-01"))
        for identidade in (None, "", [], {}, 123):
            with self.subTest(identidade=identidade):
                self.assertFalse(seguranca.autenticar_dispositivo(self.headers, identidade))

    def test_cabecalho_independe_de_maiusculas(self):
        self.assertTrue(seguranca.autenticar_dispositivo(
            {"x-DeViCe-KeY": "chave-ficticia-sensor-01"}, "esp32-travessia-01"))

    def test_cabecalhos_duplicados_negam(self):
        headers = dict(self.headers, **{"x-device-key": "chave-ficticia-sensor-01"})
        self.assertFalse(seguranca.autenticar_dispositivo(headers, "esp32-travessia-01"))

    def test_chave_nao_tem_espacos_removidos(self):
        self.assertFalse(seguranca.autenticar_dispositivo(
            {"X-Device-Key": " chave-ficticia-sensor-01 "}, "esp32-travessia-01"))

    def test_fallback_exige_par_completo(self):
        del os.environ["DEVICE_KEYS_JSON"]
        os.environ["DEVICE_ID"] = "esp32-travessia-01"
        self.assertFalse(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))
        os.environ["DEVICE_KEY"] = "chave-ficticia-sensor-01"
        self.assertTrue(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))

    def test_json_invalido_nunca_usa_fallback(self):
        os.environ.update(DEVICE_ID="esp32-travessia-01", DEVICE_KEY="chave-ficticia-sensor-01")
        invalidos = ["", "{", "[]", "null", "{}", '{"esp32-travessia-01": 123}',
                     '{"esp32-travessia-01": "chave-ficticia-sensor-01", "outro": ""}',
                     '{"esp32-travessia-01":"a", "esp32-travessia-01":"chave-ficticia-sensor-01"}']
        for configuracao in invalidos:
            with self.subTest(configuracao=configuracao):
                os.environ["DEVICE_KEYS_JSON"] = configuracao
                self.assertFalse(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))
                self.assertFalse(seguranca.autenticar_leitura(self.headers))

    def test_sem_configuracao_nega(self):
        os.environ.clear()
        self.assertFalse(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))
        self.assertFalse(seguranca.autenticar_leitura(self.headers))

    def test_leitura_aceita_chave_de_sensor_cadastrado(self):
        self.assertTrue(seguranca.autenticar_leitura(self.headers))
        self.assertFalse(seguranca.autenticar_leitura({"X-Device-Key": "errada"}))

    def test_leitura_dedicada_exige_x_read_key(self):
        os.environ["READ_API_KEY"] = "chave-ficticia-leitura"
        self.assertTrue(seguranca.autenticar_leitura({"x-read-key": "chave-ficticia-leitura"}))
        self.assertFalse(seguranca.autenticar_leitura(self.headers))
        self.assertFalse(seguranca.autenticar_leitura({"X-Read-Key": "errada"}))
        self.assertFalse(seguranca.autenticar_dispositivo(
            {"X-Device-Key": "chave-ficticia-leitura"}, "esp32-travessia-01"))

    def test_leitura_dedicada_vazia_nega_sem_fallback(self):
        os.environ["READ_API_KEY"] = ""
        self.assertFalse(seguranca.autenticar_leitura(self.headers))
        self.assertFalse(seguranca.autenticar_leitura({"X-Read-Key": ""}))

    def test_compare_digest_usado(self):
        with patch.object(seguranca.hmac, "compare_digest", return_value=True) as comparacao:
            self.assertTrue(seguranca.autenticar_dispositivo(self.headers, "esp32-travessia-01"))
        comparacao.assert_called_once_with(b"chave-ficticia-sensor-01", b"chave-ficticia-sensor-01")

    def test_limite_padrao_e_fronteira(self):
        self.assertEqual(seguranca.limite_corpo_bytes(), 16384)
        self.assertTrue(seguranca.corpo_no_limite(b"x" * 16384))
        self.assertFalse(seguranca.corpo_no_limite(b"x" * 16385))

    def test_limite_conta_bytes_utf8(self):
        os.environ["MAX_BODY_BYTES"] = "4"
        self.assertTrue(seguranca.corpo_no_limite("áá"))
        self.assertFalse(seguranca.corpo_no_limite("ááx"))

    def test_limite_invalido_e_corpo_invalido(self):
        for valor in ("", "zero", "-1", "0"):
            with self.subTest(valor=valor):
                os.environ["MAX_BODY_BYTES"] = valor
                self.assertEqual(seguranca.limite_corpo_bytes(), 16384)
        self.assertTrue(seguranca.corpo_no_limite(None))
        self.assertFalse(seguranca.corpo_no_limite({}))
        self.assertFalse(seguranca.corpo_no_limite("\ud800"))


if __name__ == "__main__":
    unittest.main(verbosity=2)

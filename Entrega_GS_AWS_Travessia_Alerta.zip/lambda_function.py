"""Travessia Alerta: telemetria autenticada e historico publico SP Aguas.

DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD configuram o RDS PostgreSQL.
DB_SSL_CA pode indicar o bundle de certificados RDS empacotado na Lambda.
DEVICE_KEYS_JSON configura X-Device-Key; veja seguranca.py para os detalhes.
AI_PROVIDER=comprehend (padrao) usa IAM, idioma pt e timeout curto.
HF_TOKEN habilita Hugging Face como alternativa ou fallback de Comprehend.
HF_SPACE_URL/HF_SPACE_KEY selecionam o Space Gradio, sem alterar o router padrao.
Os limiares 150/250 cm sao didaticos do ESP32: nao classificam a base real.
"""

import base64
import binascii
import csv
import hashlib
import io
import json
import logging
import math
import os
import re
import ssl
import time
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal
from urllib.parse import parse_qs, urlsplit

from seguranca import (
    autenticar_dispositivo, autenticar_leitura, corpo_no_limite, limite_corpo_bytes,
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
LIMIARES = {
    "nivel_rio_cm": {"atencao": 150.0, "critico": 250.0},
    "chuva_mm_h": {"atencao": 20.0, "critico": 50.0},
    "fumaca_ppm": {"atencao": 300.0, "critico": 600.0},
    "temperatura_c": {"atencao": 35.0, "critico": 40.0},
    "umidade_solo_pct": {"atencao": 20.0, "critico": 10.0},
}
INVERTIDAS = {"umidade_solo_pct"}
HF_MODEL = "cardiffnlp/twitter-xlm-roberta-base-sentiment"
HF_SPACE_TIMEOUT = 20.0
HF_MAX_RESPONSE_BYTES = 262_144
COLUNAS_CSV = (
    "datahora", "chuva_mm_1h", "chuva_acum_3h", "chuva_acum_6h",
    "chuva_acum_24h", "chuva_acum_72h", "nivel_cm", "nivel_max_cm",
    "variacao_nivel_1h", "variacao_nivel_3h", "hora", "mes",
    "acima_limiar", "ultrapassa_3h",
)
COLUNAS_HISTORICO = ("estacao_id", "medido_em", *COLUNAS_CSV, "origem")
COLUNAS_OCORRENCIA = (
    "dispositivo_id", "tipo_dispositivo", "latitude", "longitude", "metrica",
    "valor", "relato", "sentimento", "confianca", "nivel_risco", "medido_em",
    "evento_id", "ponto_id", "origem", "distancia_cm", "movimento",
    "status_nivel", "status_pir", "recebido_em", "payload_hash",
)
ID_VALIDO = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}\Z")


class EntradaInvalida(ValueError):
    pass


class ConflitoEvento(ValueError):
    pass


def _serializar(valor):
    if isinstance(valor, datetime):
        if valor.tzinfo is None:
            return valor.isoformat(sep=" ", timespec="seconds")
        return valor.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    if isinstance(valor, Decimal):
        return float(valor)
    raise TypeError("tipo nao serializavel")


def resposta(status, corpo, headers=None):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
            **(headers or {}),
        },
        "body": json.dumps(corpo, default=_serializar, ensure_ascii=False, allow_nan=False),
    }


def conectar():
    import pg8000

    return pg8000.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", "5432")),
        database=os.environ["DB_NAME"], user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"], timeout=8,
        ssl_context=ssl.create_default_context(cafile=os.environ.get("DB_SSL_CA")),
    )


def gravar_ocorrencia(dados):
    """Mesmo evento/conteudo retorna o mesmo ID; conteudo diferente gera 409."""
    colunas = ", ".join(COLUNAS_OCORRENCIA)
    marcadores = ", ".join(["%s"] * len(COLUNAS_OCORRENCIA))
    sql = f"""INSERT INTO ocorrencias ({colunas}) VALUES ({marcadores})
        ON CONFLICT (evento_id) WHERE evento_id IS NOT NULL DO NOTHING
        RETURNING id, criado_em"""
    conn = conectar()
    try:
        cur = conn.cursor()
        cur.execute(sql, tuple(dados.get(c) for c in COLUNAS_OCORRENCIA))
        registro = cur.fetchone()
        if registro is None:
            cur.execute(
                "SELECT id, criado_em, payload_hash FROM ocorrencias WHERE evento_id = %s",
                (dados["evento_id"],),
            )
            existente = cur.fetchone()
            if existente is None or existente[2] != dados["payload_hash"]:
                raise ConflitoEvento("evento_id ja utilizado com outros dados")
            registro = existente[:2]
        conn.commit()
        return registro
    finally:
        conn.close()


def listar_ocorrencias(limite=20):
    colunas = ("id", *COLUNAS_OCORRENCIA[:-1], "criado_em")
    conn = conectar()
    try:
        cur = conn.cursor()
        cur.execute(
            f"SELECT {', '.join(colunas)} FROM ocorrencias ORDER BY id DESC LIMIT %s",
            (limite,),
        )
        return [dict(zip(colunas, linha)) for linha in cur.fetchall()]
    finally:
        conn.close()


def classificar_risco(metrica, valor):
    faixa = LIMIARES.get(metrica)
    if faixa is None or valor is None:
        return "desconhecido"
    if metrica in INVERTIDAS:
        if valor <= faixa["critico"]:
            return "critico"
        return "atencao" if valor <= faixa["atencao"] else "normal"
    if valor >= faixa["critico"]:
        return "critico"
    return "atencao" if valor >= faixa["atencao"] else "normal"


def _sentimento_valido(rotulo, confianca):
    if not isinstance(rotulo, str) or not rotulo.strip() or len(rotulo) > 40:
        raise ValueError("rotulo de IA invalido")
    if rotulo.strip().lower() not in {"negative", "neutral", "positive", "mixed"}:
        raise ValueError("rotulo de IA invalido")
    if isinstance(confianca, bool) or not isinstance(confianca, (int, float)):
        raise ValueError("confianca de IA invalida")
    if not math.isfinite(confianca) or not 0 <= confianca <= 1:
        raise ValueError("confianca de IA invalida")
    return rotulo.strip().lower(), round(float(confianca), 4)


def _analisar_comprehend(texto):
    import boto3
    from botocore.config import Config

    cliente = boto3.client(
        "comprehend", config=Config(
            connect_timeout=4, read_timeout=4, retries={"total_max_attempts": 1},
        ),
    )
    saida = cliente.detect_sentiment(Text=texto, LanguageCode="pt")
    rotulo = saida["Sentiment"]
    confianca = saida["SentimentScore"][rotulo.title()]
    return _sentimento_valido(rotulo, confianca)


def _melhor_sentimento(saida):
    if not isinstance(saida, list) or not saida:
        raise ValueError("resposta IA invalida")
    lista = saida[0] if len(saida) == 1 and isinstance(saida[0], list) else saida
    if not lista:
        raise ValueError("resposta IA vazia")
    for item in lista:
        if not isinstance(item, dict):
            raise ValueError("resposta IA invalida")
        _sentimento_valido(item.get("label"), item.get("score"))
    # Escolha a maior pontuacao original antes de arredondar a confianca.
    melhor = max(lista, key=lambda item: item["score"])
    return _sentimento_valido(melhor["label"], melhor["score"])


class _SemRedirecionamento(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _url_space():
    """Somente o host HF fixo da configuracao; nenhuma URL vem do payload."""
    url = os.environ.get("HF_SPACE_URL", "")
    if any(caractere.isspace() for caractere in url) or any(ord(c) < 32 for c in url):
        raise ValueError("configuracao Space invalida")
    partes = urlsplit(url)
    if (partes.scheme != "https" or partes.username is not None
            or partes.password is not None or partes.port is not None
            or partes.path not in {"", "/"} or partes.query or partes.fragment
            or not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.hf\.space",
                                partes.hostname or "")):
        raise ValueError("configuracao Space invalida")
    return "https://" + partes.hostname


def _tempo_restante(prazo):
    restante = prazo - time.monotonic()
    if restante <= 0:
        raise TimeoutError("prazo IA excedido")
    return restante


def _blocos_space(retorno, prazo, limite):
    """read1 limita cada leitura; o socket recebe apenas o prazo restante.

    HTTPResponse de urllib expoe o socket em fp.raw._sock. Recalcular antes de
    cada leitura impede que heartbeats renovem o prazo absoluto da inferencia.
    """
    total = 0
    while True:
        restante = _tempo_restante(prazo)
        sock = getattr(getattr(getattr(retorno, "fp", None), "raw", None), "_sock", None)
        if sock is not None:
            sock.settimeout(restante)
        bloco = retorno.read1(min(4096, limite + 1 - total))
        _tempo_restante(prazo)
        if not bloco:
            return
        total += len(bloco)
        if total > limite:
            raise ValueError("resposta IA excede limite")
        yield bloco


def _resultado_sse(retorno, prazo):
    pendente = b""
    evento = ""
    dados = []
    for bloco in _blocos_space(retorno, prazo, HF_MAX_RESPONSE_BYTES):
        pendente += bloco
        while b"\n" in pendente:
            linha, pendente = pendente.split(b"\n", 1)
            if len(linha) > 65_536:
                raise ValueError("linha SSE excede limite")
            linha = linha.rstrip(b"\r").decode("utf-8")
            if not linha:
                if evento == "complete":
                    saida = json.loads("\n".join(dados))
                    # Um output JSON, exatamente as tres classes do Cardiff.
                    if (not isinstance(saida, list) or len(saida) != 1
                            or not isinstance(saida[0], list) or len(saida[0]) != 3):
                        raise ValueError("resultado Space invalido")
                    classes = set()
                    soma = 0.0
                    for item in saida[0]:
                        if not isinstance(item, dict):
                            raise ValueError("resultado Space invalido")
                        rotulo, _ = _sentimento_valido(item.get("label"), item.get("score"))
                        classes.add(rotulo)
                        soma += item["score"]
                    if classes != {"negative", "neutral", "positive"} or abs(soma - 1.0) > 0.001:
                        raise ValueError("resultado Space invalido")
                    return _melhor_sentimento(saida)
                if evento == "error":
                    raise ValueError("Space indisponivel")
                if evento not in {"", "heartbeat", "generating"}:
                    raise ValueError("evento SSE invalido")
                evento, dados = "", []
            elif linha.startswith("event:"):
                evento = linha[6:].lstrip(" ")
            elif linha.startswith("data:"):
                dados.append(linha[5:].lstrip(" "))
            elif not linha.startswith(":"):
                raise ValueError("SSE invalido")
        if len(pendente) > 65_536:
            raise ValueError("linha SSE excede limite")
    raise ValueError("SSE sem resultado completo")


def _analisar_space(texto, prazo):
    url = _url_space() + "/gradio_api/call/classificar"
    chave = os.environ.get("HF_SPACE_KEY", "")
    if not 32 <= len(chave) <= 512:
        raise ValueError("chave Space nao configurada")
    token = os.environ.get("HF_TOKEN")
    autenticacao = {"Authorization": f"Bearer {token}"} if token else {}
    cliente = urllib.request.build_opener(_SemRedirecionamento())
    req = urllib.request.Request(
        url, data=json.dumps({"data": [texto, chave]}).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json", "Accept": "application/json", **autenticacao},
    )
    with cliente.open(req, timeout=_tempo_restante(prazo)) as retorno:
        saida = json.loads(b"".join(_blocos_space(retorno, prazo, 4096)).decode("utf-8"))
    evento_id = saida.get("event_id") if isinstance(saida, dict) else None
    if not isinstance(evento_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", evento_id):
        raise ValueError("resposta da fila IA invalida")
    req = urllib.request.Request(url + "/" + evento_id,
                                 headers={"Accept": "text/event-stream", **autenticacao})
    with cliente.open(req, timeout=_tempo_restante(prazo)) as retorno:
        return _resultado_sse(retorno, prazo)


def _analisar_huggingface(texto, prazo=None):
    if "HF_SPACE_URL" in os.environ:
        return _analisar_space(texto, prazo if prazo is not None else time.monotonic() + HF_SPACE_TIMEOUT)
    token = os.environ.get("HF_TOKEN")
    if not token:
        return None, None
    modelo = os.environ.get("HF_MODEL", HF_MODEL)
    url = "https://router.huggingface.co/hf-inference/models/" + modelo
    req = urllib.request.Request(
        url, data=json.dumps({"inputs": texto}).encode("utf-8"), method="POST",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=4) as retorno:
        saida = json.loads(retorno.read(262_144).decode("utf-8"))
    return _melhor_sentimento(saida)


def analisar_relato(texto):
    """A indisponibilidade ou resposta invalida da IA nunca impede a gravacao."""
    if not texto:
        return None, None
    prazo = time.monotonic() + HF_SPACE_TIMEOUT
    provedor = os.environ.get("AI_PROVIDER", "comprehend").lower()
    if provedor in {"none", "desativado"}:
        logger.warning("IA INDISPONIVEL motivo=provedor_desativado")
        return None, None
    if provedor == "comprehend":
        try:
            return _analisar_comprehend(texto)
        except Exception as erro:
            logger.warning("IA INDISPONIVEL provedor=comprehend tipo=%s", type(erro).__name__)
    if (provedor in {"comprehend", "huggingface", "hf"}
            and ("HF_SPACE_URL" in os.environ or os.environ.get("HF_TOKEN"))):
        try:
            return _analisar_huggingface(texto, prazo)
        except Exception as erro:
            logger.warning("IA INDISPONIVEL provedor=huggingface tipo=%s", type(erro).__name__)
    elif provedor in {"huggingface", "hf"}:
        logger.warning("IA INDISPONIVEL provedor=huggingface motivo=token_nao_configurado")
    elif provedor != "comprehend":
        logger.warning("IA INDISPONIVEL motivo=provedor_nao_suportado")
    return None, None


def _sem_duplicatas(pares):
    resultado = {}
    for chave, valor in pares:
        if chave in resultado:
            raise EntradaInvalida("JSON com campos duplicados")
        resultado[chave] = valor
    return resultado


def _constante_invalida(_):
    raise EntradaInvalida("JSON contem numero nao finito")


def _nome_sensivel(nome):
    normalizado = re.sub(r"[^a-z0-9]", "", nome.lower())
    return normalizado == "key" or any(parte in normalizado for parte in (
        "password", "senha", "token", "secret", "credential", "credencial",
        "authorization", "apikey", "devicekey", "readkey", "accesskey", "cookie",
        "chave", "privatekey", "passphrase", "dbpass", "hfspacekey",
    ))


def _segredos_configurados(headers):
    segredos = [v for k, v in os.environ.items() if _nome_sensivel(k) and v]
    try:
        chaves = json.loads(os.environ.get("DEVICE_KEYS_JSON", "{}"))
        if isinstance(chaves, dict):
            segredos.extend(v for v in chaves.values() if isinstance(v, str) and v)
    except ValueError:
        pass
    if isinstance(headers, dict):
        segredos.extend(v for k, v in headers.items()
                        if isinstance(k, str) and _nome_sensivel(k) and isinstance(v, str) and v)
    return segredos


def _valor_para_log(valor, headers=None):
    if isinstance(valor, str) and any(s in valor for s in _segredos_configurados(headers)):
        return "[omitido]"
    return valor


def _corpo_sensivel(bruto, headers):
    """Omite corpos com credenciais; o corpo comum permanece literal, sem reconstruir.

    Inspeciona tambem nomes JSON escapados e os valores secretos configurados.
    Cabecalhos nunca sao registrados, nem mesmo em entradas invalidas.
    """
    for captura in re.finditer(r'"(?:[^"\\]|\\.)*"\s*:', bruto):
        try:
            nome = json.loads(captura.group(0).rsplit(":", 1)[0].rstrip())
        except ValueError:
            continue
        if _nome_sensivel(nome):
            return True
    segredos = _segredos_configurados(headers)
    # Compare tambem a representacao JSON: um segredo pode ter caracteres escapados.
    return any(segredo in bruto or json.dumps(segredo, ensure_ascii=True)[1:-1] in bruto
               or json.dumps(segredo, ensure_ascii=False)[1:-1] in bruto for segredo in segredos)


def _evento_para_log(payload):
    valor = payload.get("evento_id") if isinstance(payload, dict) else None
    return valor if isinstance(valor, str) and ID_VALIDO.fullmatch(valor) else None


def ler_payload(evento):
    bruto = evento.get("body")
    if not isinstance(bruto, str):
        logger.info("CORPO RECEBIDO omitido=tipo_invalido")
        raise EntradaInvalida("corpo deve ser um objeto JSON")
    if evento.get("isBase64Encoded"):
        if len(bruto) > ((limite_corpo_bytes() + 2) // 3) * 4:
            logger.info("CORPO RECEBIDO omitido=limite_excedido")
            raise EntradaInvalida("corpo excede o limite permitido")
        try:
            bruto = base64.b64decode(bruto, validate=True)
        except (ValueError, binascii.Error):
            logger.info("CORPO RECEBIDO omitido=base64_invalido")
            raise EntradaInvalida("corpo base64 invalido") from None
    if not corpo_no_limite(bruto):
        logger.info("CORPO RECEBIDO omitido=limite_excedido_ou_utf8_invalido")
        raise EntradaInvalida("corpo excede o limite permitido")
    if isinstance(bruto, bytes):
        try:
            bruto = bruto.decode("utf-8")
        except UnicodeError:
            logger.info("CORPO RECEBIDO omitido=utf8_invalido")
            raise EntradaInvalida("corpo deve usar UTF-8 valido") from None
    # JSON dentro de uma unica linha de log: controla CR/LF, NUL e Unicode.
    if _corpo_sensivel(bruto, evento.get("headers")):
        logger.info("CORPO RECEBIDO omitido=conteudo_sensivel")
    else:
        logger.info("CORPO RECEBIDO bruto=%s", json.dumps(bruto, ensure_ascii=True))
    try:
        payload = json.loads(bruto, object_pairs_hook=_sem_duplicatas, parse_constant=_constante_invalida)
    except (ValueError, UnicodeError, RecursionError):
        raise EntradaInvalida("corpo nao e um JSON valido") from None
    if not isinstance(payload, dict):
        raise EntradaInvalida("corpo deve ser um objeto JSON")
    return payload


def _texto(valor, campo, limite=128, opcional=False, identificador=False):
    if valor is None and opcional:
        return None
    if not isinstance(valor, str) or not valor.strip() or len(valor) > limite:
        raise EntradaInvalida(f"{campo}: texto invalido ou longo demais")
    if "\x00" in valor:
        raise EntradaInvalida(f"{campo}: caractere nulo nao permitido")
    try:
        valor.encode("utf-8")
    except UnicodeError:
        raise EntradaInvalida(f"{campo}: texto UTF-8 invalido") from None
    if identificador and not ID_VALIDO.fullmatch(valor):
        raise EntradaInvalida(f"{campo}: identificador invalido")
    return valor


def _numero(valor, campo, minimo=None, maximo=None, opcional=False):
    if valor is None and opcional:
        return None
    if isinstance(valor, bool) or not isinstance(valor, (int, float)):
        raise EntradaInvalida(f"{campo}: numero invalido")
    try:
        numero = float(valor)
    except (ValueError, OverflowError):
        raise EntradaInvalida(f"{campo}: numero invalido") from None
    if not math.isfinite(numero):
        raise EntradaInvalida(f"{campo}: numero deve ser finito")
    if minimo is not None and numero < minimo or maximo is not None and numero > maximo:
        raise EntradaInvalida(f"{campo}: fora da faixa permitida")
    return numero


def _instante(valor, campo):
    if not isinstance(valor, str) or len(valor) > 64 or "T" not in valor:
        raise EntradaInvalida(f"{campo}: use ISO 8601 com fuso horario")
    try:
        instante = datetime.fromisoformat(valor.replace("Z", "+00:00"))
    except ValueError:
        raise EntradaInvalida(f"{campo}: data/hora invalida") from None
    if instante.tzinfo is None or instante.utcoffset() is None:
        raise EntradaInvalida(f"{campo}: fuso horario obrigatorio")
    try:
        return instante.astimezone(timezone.utc)
    except (OverflowError, ValueError):
        raise EntradaInvalida(f"{campo}: data/hora fora da faixa suportada") from None


def validar_payload(payload):
    validar_obrigatorios(payload)
    tipo = payload.get("tipo", payload.get("tipo_dispositivo", "desconhecido"))
    if "tipo" in payload and "tipo_dispositivo" in payload and payload["tipo"] != payload["tipo_dispositivo"]:
        raise EntradaInvalida("tipo e tipo_dispositivo devem ter o mesmo valor")
    metrica = _texto(payload["metrica"], "metrica", identificador=True)
    if metrica not in LIMIARES:
        raise EntradaInvalida("metrica nao suportada")
    dados = {
        "dispositivo_id": _texto(payload["dispositivo_id"], "dispositivo_id", identificador=True),
        "tipo_dispositivo": _texto(tipo, "tipo_dispositivo", 40, identificador=True),
        "metrica": metrica, "valor": _numero(payload["valor"], "valor"),
        "latitude": _numero(payload.get("latitude"), "latitude", -90, 90, True),
        "longitude": _numero(payload.get("longitude"), "longitude", -180, 180, True),
        "distancia_cm": _numero(payload.get("distancia_cm"), "distancia_cm", 0, None, True),
        "relato": _texto(payload.get("relato"), "relato", 2000, True),
        "medido_em": _instante(payload["medido_em"], "medido_em") if payload.get("medido_em") is not None else None,
    }
    for campo in ("evento_id", "ponto_id", "origem"):
        dados[campo] = _texto(payload.get(campo), campo, 128, True, True)
    movimento = payload.get("movimento")
    if movimento is not None and not isinstance(movimento, bool):
        raise EntradaInvalida("movimento: use true ou false")
    dados["movimento"] = movimento
    for campo, permitidos in (
        ("status_nivel", {"normal", "atencao", "critico"}),
        ("status_pir", {"movimento", "sem_movimento"}),
    ):
        valor = payload.get(campo)
        if valor is not None and (not isinstance(valor, str) or valor not in permitidos):
            raise EntradaInvalida(f"{campo}: valor invalido")
        dados[campo] = valor
    if movimento is not None and dados["status_pir"] is not None:
        if dados["status_pir"] != ("movimento" if movimento else "sem_movimento"):
            raise EntradaInvalida("status_pir diverge de movimento")
    return dados


def validar_obrigatorios(payload):
    faltando = [c for c in ("dispositivo_id", "metrica", "valor") if payload.get(c) is None]
    if faltando:
        raise EntradaInvalida("campos obrigatorios ausentes: " + ", ".join(faltando))


def rota_ingestao(evento):
    payload = ler_payload(evento)
    headers = evento.get("headers")
    evento_id = _valor_para_log(_evento_para_log(payload), headers)
    try:
        validar_obrigatorios(payload)
    except EntradaInvalida:
        logger.warning("LEITURA DESCARTADA motivo=campos_obrigatorios evento_id=%s", evento_id)
        raise
    dispositivo = payload.get("dispositivo_id")
    if not autenticar_dispositivo(evento.get("headers"), dispositivo):
        logger.warning("LEITURA DESCARTADA motivo=credencial_ausente_ou_invalida evento_id=%s", evento_id)
        return resposta(401, {"erro": "credencial de dispositivo ausente ou invalida"})
    try:
        dados = validar_payload(payload)
    except EntradaInvalida:
        logger.warning("LEITURA DESCARTADA motivo=campos_invalidos evento_id=%s", evento_id)
        raise
    log_dados = {c: _valor_para_log(v, headers) for c, v in dados.items()}
    logger.info(
        "DADOS INTERPRETADOS DISPOSITIVO=%s TIPO=%s GPS=(%s,%s) %s=%s evento_id=%s ponto_id=%s",
        log_dados["dispositivo_id"], log_dados["tipo_dispositivo"], dados["latitude"],
        dados["longitude"], log_dados["metrica"], dados["valor"], evento_id, log_dados["ponto_id"],
    )
    dados["payload_hash"] = hashlib.sha256(
        json.dumps(dados, sort_keys=True, default=_serializar, ensure_ascii=False).encode("utf-8")
    ).hexdigest()
    dados["recebido_em"] = datetime.now(timezone.utc)
    dados["nivel_risco"] = classificar_risco(dados["metrica"], dados["valor"])
    dados["sentimento"], dados["confianca"] = analisar_relato(dados["relato"])
    try:
        _sentimento_valido(dados["sentimento"], dados["confianca"])
        ia_ok = bool(dados["relato"])
    except ValueError:
        ia_ok = False
    if dados["relato"] and not ia_ok:
        logger.warning("ANALISE TEXTUAL indisponivel evento_id=%s", evento_id)
    logger.info("CLASSIFICACAO risco=%s sentimento=%s confianca=%s ia_ok=%s evento_id=%s",
                dados["nivel_risco"], _valor_para_log(dados["sentimento"], headers),
                dados["confianca"], "true" if ia_ok else "false", evento_id)
    if dados["nivel_risco"] == "critico":
        logger.warning("ALERTA CIDADAO dispositivo=%s valor=%s evento_id=%s",
                       log_dados["dispositivo_id"], dados["valor"], evento_id)
    try:
        novo_id, criado_em = gravar_ocorrencia(dados)
    except ConflitoEvento:
        logger.warning("LEITURA DESCARTADA motivo=evento_id_conflitante evento_id=%s", evento_id)
        raise
    logger.info("GRAVADO NO RDS id=%s em=%s evento_id=%s", novo_id, criado_em, evento_id)
    retorno = {c: dados[c] for c in (
        "dispositivo_id", "tipo_dispositivo", "metrica", "valor", "nivel_risco", "sentimento", "confianca",
    )}
    retorno.update(id=novo_id, alerta=dados["nivel_risco"] == "critico", ia_ok=ia_ok)
    for campo in ("evento_id", "ponto_id"):
        if dados[campo] is not None:
            retorno[campo] = dados[campo]
    return resposta(201, retorno)


def parametros_consulta(evento):
    bruto = evento.get("rawQueryString")
    if bruto:
        try:
            pares = parse_qs(bruto, keep_blank_values=True, max_num_fields=20)
        except ValueError:
            raise EntradaInvalida("quantidade de parametros excedida") from None
        if any(len(valores) != 1 for valores in pares.values()):
            raise EntradaInvalida("parametros duplicados")
        return {chave: valores[0] for chave, valores in pares.items()}
    return evento.get("queryStringParameters") or {}


def _limite(parametros, padrao=100, maximo=1000):
    texto = parametros.get("limit", parametros.get("limite", str(padrao)))
    if not isinstance(texto, str) or not re.fullmatch(r"[0-9]{1,5}", texto):
        raise EntradaInvalida("limit deve ser inteiro positivo")
    limite = int(texto)
    if not 1 <= limite <= maximo:
        raise EntradaInvalida(f"limit deve estar entre 1 e {maximo}")
    return limite


def consultar_historico(parametros, csv_completo=False):
    permitidos = {"estacao_id", "inicio", "fim", "cursor", "limit", "limite"}
    if any(c not in permitidos for c in parametros):
        raise EntradaInvalida("parametro de consulta desconhecido")
    estacao = parametros.get("estacao_id", "1000480")
    if estacao != "1000480":
        raise EntradaInvalida("estacao_id suportada: 1000480")
    limite = 30_000 if csv_completo else _limite(parametros)
    condicoes = ["estacao_id = %s"]
    argumentos = [estacao]
    instantes = {}
    for campo, operador in (("inicio", ">="), ("fim", "<="), ("cursor", ">")):
        if campo in parametros:
            instante = _instante(parametros[campo], campo)
            instantes[campo] = instante
            condicoes.append(f"medido_em {operador} %s")
            argumentos.append(instante)
    if "inicio" in instantes and "fim" in instantes and instantes["inicio"] > instantes["fim"]:
        raise EntradaInvalida("inicio deve ser anterior ou igual a fim")
    argumentos.append(limite + 1)
    conn = conectar()
    try:
        cur = conn.cursor()
        cur.execute(
            f"SELECT {', '.join(COLUNAS_HISTORICO)} FROM base_historica "
            f"WHERE {' AND '.join(condicoes)} ORDER BY medido_em ASC LIMIT %s",
            tuple(argumentos),
        )
        linhas = [dict(zip(COLUNAS_HISTORICO, linha)) for linha in cur.fetchall()]
    finally:
        conn.close()
    mais = len(linhas) > limite
    if csv_completo and mais:
        raise RuntimeError("historico excede o limite de exportacao")
    linhas = linhas[:limite]
    proximo = _serializar(linhas[-1]["medido_em"]) if mais and linhas else None
    return linhas, proximo


def rota_historico(evento, csv_completo=False):
    linhas, cursor = consultar_historico(parametros_consulta(evento), csv_completo)
    if csv_completo:
        memoria = io.StringIO(newline="")
        escritor = csv.writer(memoria, lineterminator="\n")
        escritor.writerow(COLUNAS_CSV)
        for linha in linhas:
            escritor.writerow([
                _serializar(linha[c]) if isinstance(linha[c], datetime) else linha[c]
                for c in COLUNAS_CSV
            ])
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "text/csv; charset=utf-8",
                "Content-Disposition": 'attachment; filename="base_sp_aguas_tratada.csv"',
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "public, max-age=300",
            },
            "body": memoria.getvalue(),
        }
    return resposta(200, {
        "estacao_id": "1000480", "origem": "sp_aguas_sibh", "quantidade": len(linhas),
        "dados": linhas, "proximo_cursor": cursor,
        "observacao": "Historico real da estacao; lacunas preservadas como null. Limiares ESP32 nao se aplicam.",
    })


def lambda_handler(evento, contexto):
    metodo = (evento.get("requestContext", {}).get("http", {}).get("method", "GET")).upper()
    caminho = evento.get("rawPath", "/")
    logger.info("REQUISICAO metodo=%s caminho=%s", json.dumps(_valor_para_log(metodo), ensure_ascii=True),
                json.dumps(_valor_para_log(caminho), ensure_ascii=True))
    try:
        if caminho == "/" and metodo == "GET":
            return resposta(200, {
                "projeto": "Travessia Alerta", "health": "/health",
                "dados": "/dados", "download_csv": "/dados.csv",
                "ingestao": "POST /ocorrencias (X-Device-Key)",
            })
        if caminho == "/health" and metodo == "GET":
            return resposta(200, {"status": "ok", "servico": "travessia-alerta", "verificacao": "aplicacao"})
        if caminho == "/ocorrencias" and metodo == "POST":
            return rota_ingestao(evento)
        if caminho == "/ocorrencias" and metodo == "GET":
            if not autenticar_leitura(evento.get("headers")):
                return resposta(401, {"erro": "credencial de leitura ausente ou invalida"})
            return resposta(200, {"ocorrencias": listar_ocorrencias(_limite(parametros_consulta(evento), 20, 100))})
        if caminho in {"/dados", "/dados.csv"} and metodo == "GET":
            return rota_historico(evento, caminho == "/dados.csv")
        return resposta(404, {"erro": "rota nao encontrada"})
    except EntradaInvalida as erro:
        logger.warning("LEITURA OU CONSULTA DESCARTADA motivo=%s", erro)
        return resposta(400, {"erro": str(erro)})
    except ConflitoEvento:
        logger.warning("LEITURA DESCARTADA motivo=evento_id_conflitante")
        return resposta(409, {"erro": "evento_id ja utilizado com outros dados"})
    except Exception as erro:
        logger.error("ERRO INTERNO tipo=%s", type(erro).__name__)
        return resposta(500, {"erro": "falha interna ao processar requisicao"})

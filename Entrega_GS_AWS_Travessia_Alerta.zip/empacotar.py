"""Cria o ZIP da Lambda no Windows, Linux e AWS CloudShell.

python empacotar.py --output funcao.zip
Reuso offline: --skip-install --dependency-dir .deps --ca-file caminho/bundle.pem
Não inclui boto3: o runtime Python da AWS já fornece esse SDK.
"""

import argparse
import hashlib
import json
from pathlib import Path
import ssl
import subprocess
import sys
import urllib.request
import zipfile


CA_URL = "https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem"
PACKAGE_NAMES = ("pg8000", "scramp", "asn1crypto", "dateutil", "tzdata")
DIST_PREFIXES = ("pg8000-", "scramp-", "asn1crypto-", "python_dateutil-", "tzdata-", "six-")
SOURCE_FILES = ("lambda_function.py", "seguranca.py")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("funcao.zip"))
    parser.add_argument("--build-dir", type=Path, default=Path(".build"))
    parser.add_argument("--dependency-dir", type=Path)
    parser.add_argument("--skip-install", action="store_true")
    parser.add_argument("--ca-file", type=Path)
    args = parser.parse_args()
    project_dir = Path(__file__).resolve().parent
    dependency_dir = args.dependency_dir or args.build_dir / "lambda-deps"
    for name in SOURCE_FILES:
        if not (project_dir / name).is_file():
            raise RuntimeError("Arquivo obrigatório ausente: " + name)
    if not args.skip_install:
        dependency_dir.mkdir(exist_ok=True, parents=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "--target",
                        str(dependency_dir), "-r", str(project_dir / "requirements-lambda.txt")],
                       check=True)
    for name in (*PACKAGE_NAMES, "six.py"):
        if not (dependency_dir / name).exists():
            raise RuntimeError("Dependência ausente no pacote: " + name)
    ca_file = args.ca_file or args.build_dir / "rds-global-bundle.pem"
    if not ca_file.is_file():
        if args.skip_install:
            raise RuntimeError("Modo offline requer --ca-file apontando para o bundle RDS oficial existente.")
        ca_file.parent.mkdir(exist_ok=True, parents=True)
        with urllib.request.urlopen(CA_URL, timeout=30) as response:
            ca_file.write_bytes(response.read())
    ssl.create_default_context(cafile=str(ca_file))  # confirma que o arquivo contém certificados válidos
    files = {}
    for name in (*PACKAGE_NAMES, "six.py"):
        source = dependency_dir / name
        candidates = [source] if source.is_file() else source.rglob("*")
        for candidate in candidates:
            if candidate.is_file() and "__pycache__" not in candidate.parts and candidate.suffix != ".pyc":
                files[candidate.relative_to(dependency_dir).as_posix()] = candidate
    for source in dependency_dir.iterdir():
        if source.name.endswith(".dist-info") and source.name.startswith(DIST_PREFIXES):
            for candidate in source.rglob("*"):
                if candidate.is_file():
                    files[candidate.relative_to(dependency_dir).as_posix()] = candidate
    files.update({name: project_dir / name for name in SOURCE_FILES})
    files["rds-global-bundle.pem"] = ca_file
    args.output.parent.mkdir(exist_ok=True, parents=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as archive:
        for archive_name, source in sorted(files.items()):
            archive.write(source, archive_name)
    manifest = {"arquivo": args.output.name, "arquivos_no_pacote": len(files),
                "bytes": args.output.stat().st_size,
                "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                "dependencias": (project_dir / "requirements-lambda.txt").read_text().splitlines()}
    args.output.with_suffix(".manifesto.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
